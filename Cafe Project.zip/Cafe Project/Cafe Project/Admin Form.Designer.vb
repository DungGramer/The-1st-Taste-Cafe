﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Admin_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Form))
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.Panel6 = New System.Windows.Forms.Panel()
		Me.PictureBox1 = New System.Windows.Forms.PictureBox()
		Me.Panel2 = New System.Windows.Forms.Panel()
		Me.Button1 = New System.Windows.Forms.Button()
		Me.TabControl1 = New System.Windows.Forms.TabControl()
		Me.tabCafe = New System.Windows.Forms.TabPage()
		Me.picCafeFin = New System.Windows.Forms.PictureBox()
		Me.lblCafeFin = New System.Windows.Forms.LinkLabel()
		Me.lblCafeAmericano = New System.Windows.Forms.LinkLabel()
		Me.picAmericano = New System.Windows.Forms.PictureBox()
		Me.lblCafeFlatWhite = New System.Windows.Forms.LinkLabel()
		Me.picCafeFlatWhite = New System.Windows.Forms.PictureBox()
		Me.lblCapuchino = New System.Windows.Forms.LinkLabel()
		Me.picCapuchino = New System.Windows.Forms.PictureBox()
		Me.lblCacaoNong = New System.Windows.Forms.LinkLabel()
		Me.picCacaoNong = New System.Windows.Forms.PictureBox()
		Me.lblCafeKemChesse = New System.Windows.Forms.LinkLabel()
		Me.picCafeKemChesse = New System.Windows.Forms.PictureBox()
		Me.lblCafeLatte = New System.Windows.Forms.LinkLabel()
		Me.picCafeLatte = New System.Windows.Forms.PictureBox()
		Me.lblCafeDen = New System.Windows.Forms.LinkLabel()
		Me.lblCafeLac = New System.Windows.Forms.LinkLabel()
		Me.lblBacXiu = New System.Windows.Forms.LinkLabel()
		Me.picCafeDen = New System.Windows.Forms.PictureBox()
		Me.picCafeLac = New System.Windows.Forms.PictureBox()
		Me.picBacXiu = New System.Windows.Forms.PictureBox()
		Me.lblCafeCocktail = New System.Windows.Forms.LinkLabel()
		Me.lblCafeHoaTan = New System.Windows.Forms.LinkLabel()
		Me.lblCafeRangXay = New System.Windows.Forms.LinkLabel()
		Me.lblCafeDa = New System.Windows.Forms.LinkLabel()
		Me.lblCafeNong = New System.Windows.Forms.LinkLabel()
		Me.picCafeCocktail = New System.Windows.Forms.PictureBox()
		Me.picCafeNong = New System.Windows.Forms.PictureBox()
		Me.picCafeHoaTan = New System.Windows.Forms.PictureBox()
		Me.picCafeRangXay = New System.Windows.Forms.PictureBox()
		Me.picCafeDa = New System.Windows.Forms.PictureBox()
		Me.tabDoAnKhac = New System.Windows.Forms.TabPage()
		Me.lblTraChanh = New System.Windows.Forms.LinkLabel()
		Me.lblSinhTo = New System.Windows.Forms.LinkLabel()
		Me.lblTraTuiLoc = New System.Windows.Forms.LinkLabel()
		Me.lblTraXanh = New System.Windows.Forms.LinkLabel()
		Me.picTraChanh = New System.Windows.Forms.PictureBox()
		Me.picSinhTo = New System.Windows.Forms.PictureBox()
		Me.picTraTuiLoc = New System.Windows.Forms.PictureBox()
		Me.picTraXanh = New System.Windows.Forms.PictureBox()
		Me.tabDoAnKem = New System.Windows.Forms.TabPage()
		Me.lblBanhSungBo = New System.Windows.Forms.LinkLabel()
		Me.picBanhSungBo = New System.Windows.Forms.PictureBox()
		Me.Panel3 = New System.Windows.Forms.Panel()
		Me.Button2 = New System.Windows.Forms.Button()
		Me.btInHoaDon = New System.Windows.Forms.Button()
		Me.btReset = New System.Windows.Forms.Button()
		Me.btTienThua = New System.Windows.Forms.Button()
		Me.btTotal = New System.Windows.Forms.Button()
		Me.rtbTen = New System.Windows.Forms.RichTextBox()
		Me.rtbGia = New System.Windows.Forms.RichTextBox()
		Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
		Me.txtTienThua = New System.Windows.Forms.TextBox()
		Me.txtKhachDua = New System.Windows.Forms.TextBox()
		Me.txtTotal = New System.Windows.Forms.TextBox()
		Me.Panel1.SuspendLayout()
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.TabControl1.SuspendLayout()
		Me.tabCafe.SuspendLayout()
		CType(Me.picCafeFin, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picAmericano, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeFlatWhite, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCapuchino, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCacaoNong, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeKemChesse, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeLatte, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeDen, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeLac, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picBacXiu, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeCocktail, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeNong, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeHoaTan, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeRangXay, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picCafeDa, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.tabDoAnKhac.SuspendLayout()
		CType(Me.picTraChanh, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picSinhTo, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picTraTuiLoc, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.picTraXanh, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.tabDoAnKem.SuspendLayout()
		CType(Me.picBanhSungBo, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.Panel3.SuspendLayout()
		Me.SuspendLayout()
		'
		'Panel1
		'
		Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(106, Byte), Integer), CType(CType(77, Byte), Integer))
		Me.Panel1.Controls.Add(Me.Panel6)
		Me.Panel1.Controls.Add(Me.PictureBox1)
		Me.Panel1.Controls.Add(Me.Panel2)
		Me.Panel1.Controls.Add(Me.Button1)
		Me.Panel1.Location = New System.Drawing.Point(0, 0)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(183, 627)
		Me.Panel1.TabIndex = 4
		'
		'Panel6
		'
		Me.Panel6.Location = New System.Drawing.Point(180, 25)
		Me.Panel6.Name = "Panel6"
		Me.Panel6.Size = New System.Drawing.Size(969, 587)
		Me.Panel6.TabIndex = 25
		'
		'PictureBox1
		'
		Me.PictureBox1.Image = Global.WindowsApp1.My.Resources.Resources.logo2
		Me.PictureBox1.Location = New System.Drawing.Point(-4, 0)
		Me.PictureBox1.Name = "PictureBox1"
		Me.PictureBox1.Size = New System.Drawing.Size(187, 187)
		Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PictureBox1.TabIndex = 5
		Me.PictureBox1.TabStop = False
		'
		'Panel2
		'
		Me.Panel2.BackColor = System.Drawing.Color.White
		Me.Panel2.Location = New System.Drawing.Point(0, 242)
		Me.Panel2.Name = "Panel2"
		Me.Panel2.Size = New System.Drawing.Size(13, 59)
		Me.Panel2.TabIndex = 5
		'
		'Button1
		'
		Me.Button1.FlatAppearance.BorderSize = 0
		Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.Button1.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Button1.ForeColor = System.Drawing.Color.White
		Me.Button1.Image = Global.WindowsApp1.My.Resources.Resources._1296883
		Me.Button1.Location = New System.Drawing.Point(-10, 242)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(180, 59)
		Me.Button1.TabIndex = 0
		Me.Button1.Text = "   Đặt Món"
		Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		Me.Button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
		Me.Button1.UseVisualStyleBackColor = True
		'
		'TabControl1
		'
		Me.TabControl1.Controls.Add(Me.tabCafe)
		Me.TabControl1.Controls.Add(Me.tabDoAnKhac)
		Me.TabControl1.Controls.Add(Me.tabDoAnKem)
		Me.TabControl1.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TabControl1.HotTrack = True
		Me.TabControl1.Location = New System.Drawing.Point(1, 32)
		Me.TabControl1.Name = "TabControl1"
		Me.TabControl1.SelectedIndex = 0
		Me.TabControl1.Size = New System.Drawing.Size(664, 588)
		Me.TabControl1.TabIndex = 3
		'
		'tabCafe
		'
		Me.tabCafe.BackColor = System.Drawing.SystemColors.ControlLight
		Me.tabCafe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
		Me.tabCafe.Controls.Add(Me.picCafeFin)
		Me.tabCafe.Controls.Add(Me.lblCafeFin)
		Me.tabCafe.Controls.Add(Me.lblCafeAmericano)
		Me.tabCafe.Controls.Add(Me.picAmericano)
		Me.tabCafe.Controls.Add(Me.lblCafeFlatWhite)
		Me.tabCafe.Controls.Add(Me.picCafeFlatWhite)
		Me.tabCafe.Controls.Add(Me.lblCapuchino)
		Me.tabCafe.Controls.Add(Me.picCapuchino)
		Me.tabCafe.Controls.Add(Me.lblCacaoNong)
		Me.tabCafe.Controls.Add(Me.picCacaoNong)
		Me.tabCafe.Controls.Add(Me.lblCafeKemChesse)
		Me.tabCafe.Controls.Add(Me.picCafeKemChesse)
		Me.tabCafe.Controls.Add(Me.lblCafeLatte)
		Me.tabCafe.Controls.Add(Me.picCafeLatte)
		Me.tabCafe.Controls.Add(Me.lblCafeDen)
		Me.tabCafe.Controls.Add(Me.lblCafeLac)
		Me.tabCafe.Controls.Add(Me.lblBacXiu)
		Me.tabCafe.Controls.Add(Me.picCafeDen)
		Me.tabCafe.Controls.Add(Me.picCafeLac)
		Me.tabCafe.Controls.Add(Me.picBacXiu)
		Me.tabCafe.Controls.Add(Me.lblCafeCocktail)
		Me.tabCafe.Controls.Add(Me.lblCafeHoaTan)
		Me.tabCafe.Controls.Add(Me.lblCafeRangXay)
		Me.tabCafe.Controls.Add(Me.lblCafeDa)
		Me.tabCafe.Controls.Add(Me.lblCafeNong)
		Me.tabCafe.Controls.Add(Me.picCafeCocktail)
		Me.tabCafe.Controls.Add(Me.picCafeNong)
		Me.tabCafe.Controls.Add(Me.picCafeHoaTan)
		Me.tabCafe.Controls.Add(Me.picCafeRangXay)
		Me.tabCafe.Controls.Add(Me.picCafeDa)
		Me.tabCafe.Cursor = System.Windows.Forms.Cursors.Hand
		Me.tabCafe.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.tabCafe.Location = New System.Drawing.Point(4, 27)
		Me.tabCafe.Name = "tabCafe"
		Me.tabCafe.Padding = New System.Windows.Forms.Padding(3)
		Me.tabCafe.Size = New System.Drawing.Size(656, 557)
		Me.tabCafe.TabIndex = 0
		Me.tabCafe.Text = "Cafe"
		'
		'picCafeFin
		'
		Me.picCafeFin.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeFin.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeFin.Image = Global.WindowsApp1.My.Resources.Resources.cafe_fin
		Me.picCafeFin.Location = New System.Drawing.Point(407, 228)
		Me.picCafeFin.Name = "picCafeFin"
		Me.picCafeFin.Size = New System.Drawing.Size(100, 100)
		Me.picCafeFin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeFin.TabIndex = 29
		Me.picCafeFin.TabStop = False
		'
		'lblCafeFin
		'
		Me.lblCafeFin.AutoSize = True
		Me.lblCafeFin.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeFin.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeFin.LinkColor = System.Drawing.Color.Black
		Me.lblCafeFin.Location = New System.Drawing.Point(425, 335)
		Me.lblCafeFin.Name = "lblCafeFin"
		Me.lblCafeFin.Size = New System.Drawing.Size(72, 18)
		Me.lblCafeFin.TabIndex = 28
		Me.lblCafeFin.TabStop = True
		Me.lblCafeFin.Text = "Cafe Fin"
		'
		'lblCafeAmericano
		'
		Me.lblCafeAmericano.AutoSize = True
		Me.lblCafeAmericano.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeAmericano.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeAmericano.LinkColor = System.Drawing.Color.Black
		Me.lblCafeAmericano.Location = New System.Drawing.Point(404, 518)
		Me.lblCafeAmericano.Name = "lblCafeAmericano"
		Me.lblCafeAmericano.Size = New System.Drawing.Size(120, 18)
		Me.lblCafeAmericano.TabIndex = 27
		Me.lblCafeAmericano.TabStop = True
		Me.lblCafeAmericano.Text = "Cafe Americano"
		'
		'picAmericano
		'
		Me.picAmericano.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picAmericano.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picAmericano.Image = Global.WindowsApp1.My.Resources.Resources._129688
		Me.picAmericano.Location = New System.Drawing.Point(407, 400)
		Me.picAmericano.Name = "picAmericano"
		Me.picAmericano.Size = New System.Drawing.Size(100, 100)
		Me.picAmericano.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picAmericano.TabIndex = 26
		Me.picAmericano.TabStop = False
		'
		'lblCafeFlatWhite
		'
		Me.lblCafeFlatWhite.AutoSize = True
		Me.lblCafeFlatWhite.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeFlatWhite.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeFlatWhite.LinkColor = System.Drawing.Color.Black
		Me.lblCafeFlatWhite.Location = New System.Drawing.Point(269, 518)
		Me.lblCafeFlatWhite.Name = "lblCafeFlatWhite"
		Me.lblCafeFlatWhite.Size = New System.Drawing.Size(128, 18)
		Me.lblCafeFlatWhite.TabIndex = 25
		Me.lblCafeFlatWhite.TabStop = True
		Me.lblCafeFlatWhite.Text = "Cafe Flat White"
		'
		'picCafeFlatWhite
		'
		Me.picCafeFlatWhite.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeFlatWhite.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeFlatWhite.Image = Global.WindowsApp1.My.Resources.Resources.cafe_flat_white_2
		Me.picCafeFlatWhite.Location = New System.Drawing.Point(272, 400)
		Me.picCafeFlatWhite.Name = "picCafeFlatWhite"
		Me.picCafeFlatWhite.Size = New System.Drawing.Size(100, 100)
		Me.picCafeFlatWhite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeFlatWhite.TabIndex = 24
		Me.picCafeFlatWhite.TabStop = False
		'
		'lblCapuchino
		'
		Me.lblCapuchino.AutoSize = True
		Me.lblCapuchino.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCapuchino.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCapuchino.LinkColor = System.Drawing.Color.Black
		Me.lblCapuchino.Location = New System.Drawing.Point(148, 518)
		Me.lblCapuchino.Name = "lblCapuchino"
		Me.lblCapuchino.Size = New System.Drawing.Size(80, 18)
		Me.lblCapuchino.TabIndex = 23
		Me.lblCapuchino.TabStop = True
		Me.lblCapuchino.Text = "Capuchino"
		'
		'picCapuchino
		'
		Me.picCapuchino.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCapuchino.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCapuchino.Image = Global.WindowsApp1.My.Resources.Resources.capuchino1
		Me.picCapuchino.Location = New System.Drawing.Point(139, 400)
		Me.picCapuchino.Name = "picCapuchino"
		Me.picCapuchino.Size = New System.Drawing.Size(100, 100)
		Me.picCapuchino.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCapuchino.TabIndex = 22
		Me.picCapuchino.TabStop = False
		'
		'lblCacaoNong
		'
		Me.lblCacaoNong.AutoSize = True
		Me.lblCacaoNong.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCacaoNong.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCacaoNong.LinkColor = System.Drawing.Color.Black
		Me.lblCacaoNong.Location = New System.Drawing.Point(9, 518)
		Me.lblCacaoNong.Name = "lblCacaoNong"
		Me.lblCacaoNong.Size = New System.Drawing.Size(88, 18)
		Me.lblCacaoNong.TabIndex = 21
		Me.lblCacaoNong.TabStop = True
		Me.lblCacaoNong.Text = "Cacao Nóng"
		'
		'picCacaoNong
		'
		Me.picCacaoNong.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCacaoNong.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCacaoNong.Image = Global.WindowsApp1.My.Resources.Resources.Cacao_Nong
		Me.picCacaoNong.Location = New System.Drawing.Point(9, 400)
		Me.picCacaoNong.Name = "picCacaoNong"
		Me.picCacaoNong.Size = New System.Drawing.Size(100, 100)
		Me.picCacaoNong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCacaoNong.TabIndex = 20
		Me.picCacaoNong.TabStop = False
		'
		'lblCafeKemChesse
		'
		Me.lblCafeKemChesse.AutoSize = True
		Me.lblCafeKemChesse.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeKemChesse.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeKemChesse.LinkColor = System.Drawing.Color.Black
		Me.lblCafeKemChesse.Location = New System.Drawing.Point(524, 335)
		Me.lblCafeKemChesse.Name = "lblCafeKemChesse"
		Me.lblCafeKemChesse.Size = New System.Drawing.Size(128, 18)
		Me.lblCafeKemChesse.TabIndex = 19
		Me.lblCafeKemChesse.TabStop = True
		Me.lblCafeKemChesse.Text = "Cafe Kem Cheese"
		'
		'picCafeKemChesse
		'
		Me.picCafeKemChesse.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeKemChesse.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeKemChesse.Image = Global.WindowsApp1.My.Resources.Resources.cafe_kem_cheese
		Me.picCafeKemChesse.Location = New System.Drawing.Point(540, 223)
		Me.picCafeKemChesse.Name = "picCafeKemChesse"
		Me.picCafeKemChesse.Size = New System.Drawing.Size(100, 100)
		Me.picCafeKemChesse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeKemChesse.TabIndex = 18
		Me.picCafeKemChesse.TabStop = False
		'
		'lblCafeLatte
		'
		Me.lblCafeLatte.AutoSize = True
		Me.lblCafeLatte.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeLatte.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeLatte.LinkColor = System.Drawing.Color.Black
		Me.lblCafeLatte.Location = New System.Drawing.Point(549, 518)
		Me.lblCafeLatte.Name = "lblCafeLatte"
		Me.lblCafeLatte.Size = New System.Drawing.Size(88, 18)
		Me.lblCafeLatte.TabIndex = 17
		Me.lblCafeLatte.TabStop = True
		Me.lblCafeLatte.Text = "Cafe Latte"
		'
		'picCafeLatte
		'
		Me.picCafeLatte.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeLatte.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeLatte.Image = Global.WindowsApp1.My.Resources.Resources.cafe_latte
		Me.picCafeLatte.Location = New System.Drawing.Point(540, 400)
		Me.picCafeLatte.Name = "picCafeLatte"
		Me.picCafeLatte.Size = New System.Drawing.Size(100, 100)
		Me.picCafeLatte.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeLatte.TabIndex = 16
		Me.picCafeLatte.TabStop = False
		'
		'lblCafeDen
		'
		Me.lblCafeDen.AutoSize = True
		Me.lblCafeDen.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeDen.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeDen.LinkColor = System.Drawing.Color.Black
		Me.lblCafeDen.Location = New System.Drawing.Point(284, 335)
		Me.lblCafeDen.Name = "lblCafeDen"
		Me.lblCafeDen.Size = New System.Drawing.Size(72, 18)
		Me.lblCafeDen.TabIndex = 15
		Me.lblCafeDen.TabStop = True
		Me.lblCafeDen.Text = "Cafe Đen"
		'
		'lblCafeLac
		'
		Me.lblCafeLac.AutoSize = True
		Me.lblCafeLac.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeLac.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeLac.LinkColor = System.Drawing.Color.Black
		Me.lblCafeLac.Location = New System.Drawing.Point(160, 335)
		Me.lblCafeLac.Name = "lblCafeLac"
		Me.lblCafeLac.Size = New System.Drawing.Size(72, 18)
		Me.lblCafeLac.TabIndex = 14
		Me.lblCafeLac.TabStop = True
		Me.lblCafeLac.Text = "Cafe Lắc"
		'
		'lblBacXiu
		'
		Me.lblBacXiu.AutoSize = True
		Me.lblBacXiu.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblBacXiu.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblBacXiu.LinkColor = System.Drawing.Color.Black
		Me.lblBacXiu.Location = New System.Drawing.Point(20, 335)
		Me.lblBacXiu.Name = "lblBacXiu"
		Me.lblBacXiu.Size = New System.Drawing.Size(64, 18)
		Me.lblBacXiu.TabIndex = 13
		Me.lblBacXiu.TabStop = True
		Me.lblBacXiu.Text = "Bạc Xỉu"
		'
		'picCafeDen
		'
		Me.picCafeDen.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeDen.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeDen.Image = Global.WindowsApp1.My.Resources.Resources.cafe_den
		Me.picCafeDen.Location = New System.Drawing.Point(268, 223)
		Me.picCafeDen.Name = "picCafeDen"
		Me.picCafeDen.Size = New System.Drawing.Size(100, 100)
		Me.picCafeDen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeDen.TabIndex = 12
		Me.picCafeDen.TabStop = False
		'
		'picCafeLac
		'
		Me.picCafeLac.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeLac.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeLac.Image = Global.WindowsApp1.My.Resources.Resources.cafe_lac
		Me.picCafeLac.Location = New System.Drawing.Point(139, 223)
		Me.picCafeLac.Name = "picCafeLac"
		Me.picCafeLac.Size = New System.Drawing.Size(100, 100)
		Me.picCafeLac.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeLac.TabIndex = 11
		Me.picCafeLac.TabStop = False
		'
		'picBacXiu
		'
		Me.picBacXiu.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picBacXiu.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picBacXiu.Image = Global.WindowsApp1.My.Resources.Resources.Bac_Xiu
		Me.picBacXiu.Location = New System.Drawing.Point(9, 223)
		Me.picBacXiu.Name = "picBacXiu"
		Me.picBacXiu.Size = New System.Drawing.Size(100, 100)
		Me.picBacXiu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picBacXiu.TabIndex = 10
		Me.picBacXiu.TabStop = False
		'
		'lblCafeCocktail
		'
		Me.lblCafeCocktail.AutoSize = True
		Me.lblCafeCocktail.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeCocktail.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeCocktail.LinkColor = System.Drawing.Color.Black
		Me.lblCafeCocktail.Location = New System.Drawing.Point(540, 159)
		Me.lblCafeCocktail.Name = "lblCafeCocktail"
		Me.lblCafeCocktail.Size = New System.Drawing.Size(112, 18)
		Me.lblCafeCocktail.TabIndex = 9
		Me.lblCafeCocktail.TabStop = True
		Me.lblCafeCocktail.Text = "Cafe Cocktail"
		'
		'lblCafeHoaTan
		'
		Me.lblCafeHoaTan.AutoSize = True
		Me.lblCafeHoaTan.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeHoaTan.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeHoaTan.LinkColor = System.Drawing.Color.Black
		Me.lblCafeHoaTan.Location = New System.Drawing.Point(405, 159)
		Me.lblCafeHoaTan.Name = "lblCafeHoaTan"
		Me.lblCafeHoaTan.Size = New System.Drawing.Size(104, 18)
		Me.lblCafeHoaTan.TabIndex = 8
		Me.lblCafeHoaTan.TabStop = True
		Me.lblCafeHoaTan.Text = "Cafe Hoà Tan"
		'
		'lblCafeRangXay
		'
		Me.lblCafeRangXay.AutoSize = True
		Me.lblCafeRangXay.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeRangXay.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeRangXay.LinkColor = System.Drawing.Color.Black
		Me.lblCafeRangXay.Location = New System.Drawing.Point(265, 159)
		Me.lblCafeRangXay.Name = "lblCafeRangXay"
		Me.lblCafeRangXay.Size = New System.Drawing.Size(112, 18)
		Me.lblCafeRangXay.TabIndex = 7
		Me.lblCafeRangXay.TabStop = True
		Me.lblCafeRangXay.Text = "Cafe Rang Xay"
		'
		'lblCafeDa
		'
		Me.lblCafeDa.AutoSize = True
		Me.lblCafeDa.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeDa.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeDa.LinkColor = System.Drawing.Color.Black
		Me.lblCafeDa.Location = New System.Drawing.Point(160, 159)
		Me.lblCafeDa.Name = "lblCafeDa"
		Me.lblCafeDa.Size = New System.Drawing.Size(64, 18)
		Me.lblCafeDa.TabIndex = 6
		Me.lblCafeDa.TabStop = True
		Me.lblCafeDa.Text = "Cafe Đá"
		'
		'lblCafeNong
		'
		Me.lblCafeNong.AutoSize = True
		Me.lblCafeNong.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCafeNong.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblCafeNong.LinkColor = System.Drawing.Color.Black
		Me.lblCafeNong.Location = New System.Drawing.Point(9, 159)
		Me.lblCafeNong.Name = "lblCafeNong"
		Me.lblCafeNong.Size = New System.Drawing.Size(80, 18)
		Me.lblCafeNong.TabIndex = 5
		Me.lblCafeNong.TabStop = True
		Me.lblCafeNong.Text = "Cafe Nóng"
		'
		'picCafeCocktail
		'
		Me.picCafeCocktail.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeCocktail.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeCocktail.Image = Global.WindowsApp1.My.Resources.Resources.cafe_cocktail
		Me.picCafeCocktail.Location = New System.Drawing.Point(540, 47)
		Me.picCafeCocktail.Name = "picCafeCocktail"
		Me.picCafeCocktail.Size = New System.Drawing.Size(100, 100)
		Me.picCafeCocktail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeCocktail.TabIndex = 4
		Me.picCafeCocktail.TabStop = False
		'
		'picCafeNong
		'
		Me.picCafeNong.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeNong.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeNong.Image = Global.WindowsApp1.My.Resources.Resources._129687
		Me.picCafeNong.Location = New System.Drawing.Point(6, 47)
		Me.picCafeNong.Name = "picCafeNong"
		Me.picCafeNong.Size = New System.Drawing.Size(100, 100)
		Me.picCafeNong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeNong.TabIndex = 0
		Me.picCafeNong.TabStop = False
		'
		'picCafeHoaTan
		'
		Me.picCafeHoaTan.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeHoaTan.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeHoaTan.Image = Global.WindowsApp1.My.Resources.Resources.cafe_hoà_tan
		Me.picCafeHoaTan.Location = New System.Drawing.Point(407, 47)
		Me.picCafeHoaTan.Name = "picCafeHoaTan"
		Me.picCafeHoaTan.Size = New System.Drawing.Size(100, 100)
		Me.picCafeHoaTan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeHoaTan.TabIndex = 3
		Me.picCafeHoaTan.TabStop = False
		'
		'picCafeRangXay
		'
		Me.picCafeRangXay.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeRangXay.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeRangXay.Image = Global.WindowsApp1.My.Resources.Resources._129683
		Me.picCafeRangXay.Location = New System.Drawing.Point(268, 47)
		Me.picCafeRangXay.Name = "picCafeRangXay"
		Me.picCafeRangXay.Size = New System.Drawing.Size(100, 100)
		Me.picCafeRangXay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeRangXay.TabIndex = 1
		Me.picCafeRangXay.TabStop = False
		'
		'picCafeDa
		'
		Me.picCafeDa.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picCafeDa.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picCafeDa.Image = Global.WindowsApp1.My.Resources.Resources.iced_coffee
		Me.picCafeDa.Location = New System.Drawing.Point(139, 47)
		Me.picCafeDa.Name = "picCafeDa"
		Me.picCafeDa.Size = New System.Drawing.Size(100, 100)
		Me.picCafeDa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picCafeDa.TabIndex = 2
		Me.picCafeDa.TabStop = False
		'
		'tabDoAnKhac
		'
		Me.tabDoAnKhac.BackColor = System.Drawing.SystemColors.ControlLight
		Me.tabDoAnKhac.Controls.Add(Me.lblTraChanh)
		Me.tabDoAnKhac.Controls.Add(Me.lblSinhTo)
		Me.tabDoAnKhac.Controls.Add(Me.lblTraTuiLoc)
		Me.tabDoAnKhac.Controls.Add(Me.lblTraXanh)
		Me.tabDoAnKhac.Controls.Add(Me.picTraChanh)
		Me.tabDoAnKhac.Controls.Add(Me.picSinhTo)
		Me.tabDoAnKhac.Controls.Add(Me.picTraTuiLoc)
		Me.tabDoAnKhac.Controls.Add(Me.picTraXanh)
		Me.tabDoAnKhac.Cursor = System.Windows.Forms.Cursors.Hand
		Me.tabDoAnKhac.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.tabDoAnKhac.Location = New System.Drawing.Point(4, 27)
		Me.tabDoAnKhac.Name = "tabDoAnKhac"
		Me.tabDoAnKhac.Padding = New System.Windows.Forms.Padding(3)
		Me.tabDoAnKhac.Size = New System.Drawing.Size(656, 557)
		Me.tabDoAnKhac.TabIndex = 1
		Me.tabDoAnKhac.Text = "Đồ Uống Khác"
		'
		'lblTraChanh
		'
		Me.lblTraChanh.AutoSize = True
		Me.lblTraChanh.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblTraChanh.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblTraChanh.LinkColor = System.Drawing.Color.Black
		Me.lblTraChanh.Location = New System.Drawing.Point(417, 164)
		Me.lblTraChanh.Name = "lblTraChanh"
		Me.lblTraChanh.Size = New System.Drawing.Size(80, 18)
		Me.lblTraChanh.TabIndex = 12
		Me.lblTraChanh.TabStop = True
		Me.lblTraChanh.Text = "Trà Chanh"
		'
		'lblSinhTo
		'
		Me.lblSinhTo.AutoSize = True
		Me.lblSinhTo.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblSinhTo.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblSinhTo.LinkColor = System.Drawing.Color.Black
		Me.lblSinhTo.Location = New System.Drawing.Point(296, 164)
		Me.lblSinhTo.Name = "lblSinhTo"
		Me.lblSinhTo.Size = New System.Drawing.Size(64, 18)
		Me.lblSinhTo.TabIndex = 10
		Me.lblSinhTo.TabStop = True
		Me.lblSinhTo.Text = "Sinh Tố"
		'
		'lblTraTuiLoc
		'
		Me.lblTraTuiLoc.AutoSize = True
		Me.lblTraTuiLoc.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblTraTuiLoc.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblTraTuiLoc.LinkColor = System.Drawing.Color.Black
		Me.lblTraTuiLoc.Location = New System.Drawing.Point(152, 164)
		Me.lblTraTuiLoc.Name = "lblTraTuiLoc"
		Me.lblTraTuiLoc.Size = New System.Drawing.Size(96, 18)
		Me.lblTraTuiLoc.TabIndex = 8
		Me.lblTraTuiLoc.TabStop = True
		Me.lblTraTuiLoc.Text = "Trà Túi Lọc"
		'
		'lblTraXanh
		'
		Me.lblTraXanh.AutoSize = True
		Me.lblTraXanh.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblTraXanh.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblTraXanh.LinkColor = System.Drawing.Color.Black
		Me.lblTraXanh.Location = New System.Drawing.Point(18, 164)
		Me.lblTraXanh.Name = "lblTraXanh"
		Me.lblTraXanh.Size = New System.Drawing.Size(72, 18)
		Me.lblTraXanh.TabIndex = 6
		Me.lblTraXanh.TabStop = True
		Me.lblTraXanh.Text = "Trà Xanh"
		'
		'picTraChanh
		'
		Me.picTraChanh.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picTraChanh.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picTraChanh.Image = Global.WindowsApp1.My.Resources.Resources.Tra_chanh
		Me.picTraChanh.Location = New System.Drawing.Point(407, 47)
		Me.picTraChanh.Name = "picTraChanh"
		Me.picTraChanh.Size = New System.Drawing.Size(100, 100)
		Me.picTraChanh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picTraChanh.TabIndex = 11
		Me.picTraChanh.TabStop = False
		'
		'picSinhTo
		'
		Me.picSinhTo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picSinhTo.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picSinhTo.Image = Global.WindowsApp1.My.Resources.Resources.sinh_to_da
		Me.picSinhTo.Location = New System.Drawing.Point(277, 47)
		Me.picSinhTo.Name = "picSinhTo"
		Me.picSinhTo.Size = New System.Drawing.Size(100, 100)
		Me.picSinhTo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picSinhTo.TabIndex = 9
		Me.picSinhTo.TabStop = False
		'
		'picTraTuiLoc
		'
		Me.picTraTuiLoc.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picTraTuiLoc.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picTraTuiLoc.Image = Global.WindowsApp1.My.Resources.Resources.Tra_tui_loc
		Me.picTraTuiLoc.Location = New System.Drawing.Point(145, 47)
		Me.picTraTuiLoc.Name = "picTraTuiLoc"
		Me.picTraTuiLoc.Size = New System.Drawing.Size(100, 100)
		Me.picTraTuiLoc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picTraTuiLoc.TabIndex = 7
		Me.picTraTuiLoc.TabStop = False
		'
		'picTraXanh
		'
		Me.picTraXanh.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picTraXanh.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picTraXanh.Image = Global.WindowsApp1.My.Resources.Resources.Tra_xanh
		Me.picTraXanh.Location = New System.Drawing.Point(6, 47)
		Me.picTraXanh.Name = "picTraXanh"
		Me.picTraXanh.Size = New System.Drawing.Size(100, 100)
		Me.picTraXanh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picTraXanh.TabIndex = 1
		Me.picTraXanh.TabStop = False
		'
		'tabDoAnKem
		'
		Me.tabDoAnKem.BackColor = System.Drawing.SystemColors.ControlLight
		Me.tabDoAnKem.Controls.Add(Me.lblBanhSungBo)
		Me.tabDoAnKem.Controls.Add(Me.picBanhSungBo)
		Me.tabDoAnKem.Cursor = System.Windows.Forms.Cursors.Hand
		Me.tabDoAnKem.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.tabDoAnKem.Location = New System.Drawing.Point(4, 27)
		Me.tabDoAnKem.Name = "tabDoAnKem"
		Me.tabDoAnKem.Padding = New System.Windows.Forms.Padding(3)
		Me.tabDoAnKem.Size = New System.Drawing.Size(656, 557)
		Me.tabDoAnKem.TabIndex = 2
		Me.tabDoAnKem.Text = "Đồ Ăn Kèm"
		'
		'lblBanhSungBo
		'
		Me.lblBanhSungBo.AutoSize = True
		Me.lblBanhSungBo.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblBanhSungBo.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblBanhSungBo.LinkColor = System.Drawing.Color.Black
		Me.lblBanhSungBo.Location = New System.Drawing.Point(3, 164)
		Me.lblBanhSungBo.Name = "lblBanhSungBo"
		Me.lblBanhSungBo.Size = New System.Drawing.Size(104, 18)
		Me.lblBanhSungBo.TabIndex = 9
		Me.lblBanhSungBo.TabStop = True
		Me.lblBanhSungBo.Text = "Bánh Sừng Bò"
		'
		'picBanhSungBo
		'
		Me.picBanhSungBo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picBanhSungBo.Cursor = System.Windows.Forms.Cursors.Hand
		Me.picBanhSungBo.Image = Global.WindowsApp1.My.Resources.Resources.Banh_sung_bo
		Me.picBanhSungBo.Location = New System.Drawing.Point(6, 47)
		Me.picBanhSungBo.Name = "picBanhSungBo"
		Me.picBanhSungBo.Size = New System.Drawing.Size(100, 100)
		Me.picBanhSungBo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picBanhSungBo.TabIndex = 8
		Me.picBanhSungBo.TabStop = False
		'
		'Panel3
		'
		Me.Panel3.Controls.Add(Me.txtTotal)
		Me.Panel3.Controls.Add(Me.txtKhachDua)
		Me.Panel3.Controls.Add(Me.txtTienThua)
		Me.Panel3.Controls.Add(Me.Button2)
		Me.Panel3.Controls.Add(Me.btInHoaDon)
		Me.Panel3.Controls.Add(Me.btReset)
		Me.Panel3.Controls.Add(Me.btTienThua)
		Me.Panel3.Controls.Add(Me.btTotal)
		Me.Panel3.Controls.Add(Me.TabControl1)
		Me.Panel3.Controls.Add(Me.rtbTen)
		Me.Panel3.Controls.Add(Me.rtbGia)
		Me.Panel3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Panel3.Location = New System.Drawing.Point(183, 3)
		Me.Panel3.Name = "Panel3"
		Me.Panel3.Size = New System.Drawing.Size(974, 624)
		Me.Panel3.TabIndex = 7
		'
		'Button2
		'
		Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.Button2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(106, Byte), Integer), CType(CType(77, Byte), Integer))
		Me.Button2.Image = Global.WindowsApp1.My.Resources.Resources.khach_dua_40x40
		Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.Button2.Location = New System.Drawing.Point(666, 522)
		Me.Button2.Name = "Button2"
		Me.Button2.Size = New System.Drawing.Size(189, 44)
		Me.Button2.TabIndex = 25
		Me.Button2.Text = "Khách Đưa"
		Me.Button2.UseVisualStyleBackColor = True
		'
		'btInHoaDon
		'
		Me.btInHoaDon.BackColor = System.Drawing.SystemColors.ControlLight
		Me.btInHoaDon.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.btInHoaDon.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btInHoaDon.ForeColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(106, Byte), Integer), CType(CType(77, Byte), Integer))
		Me.btInHoaDon.Image = Global.WindowsApp1.My.Resources.Resources.print_40x40
		Me.btInHoaDon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.btInHoaDon.Location = New System.Drawing.Point(666, 3)
		Me.btInHoaDon.Name = "btInHoaDon"
		Me.btInHoaDon.Size = New System.Drawing.Size(189, 49)
		Me.btInHoaDon.TabIndex = 24
		Me.btInHoaDon.Text = "       In Hoá Đơn"
		Me.btInHoaDon.UseVisualStyleBackColor = False
		'
		'btReset
		'
		Me.btReset.BackColor = System.Drawing.SystemColors.ControlLight
		Me.btReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.btReset.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btReset.ForeColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(106, Byte), Integer), CType(CType(77, Byte), Integer))
		Me.btReset.Image = Global.WindowsApp1.My.Resources.Resources.reset_40x40
		Me.btReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.btReset.Location = New System.Drawing.Point(858, 3)
		Me.btReset.Name = "btReset"
		Me.btReset.Size = New System.Drawing.Size(107, 49)
		Me.btReset.TabIndex = 22
		Me.btReset.Text = "          Reset"
		Me.btReset.UseVisualStyleBackColor = False
		'
		'btTienThua
		'
		Me.btTienThua.BackColor = System.Drawing.SystemColors.ControlLight
		Me.btTienThua.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.btTienThua.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btTienThua.ForeColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(106, Byte), Integer), CType(CType(77, Byte), Integer))
		Me.btTienThua.Image = Global.WindowsApp1.My.Resources.Resources.tien_thua_40x40
		Me.btTienThua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.btTienThua.Location = New System.Drawing.Point(666, 572)
		Me.btTienThua.Name = "btTienThua"
		Me.btTienThua.Size = New System.Drawing.Size(189, 44)
		Me.btTienThua.TabIndex = 25
		Me.btTienThua.Text = "Tiền Thừa"
		Me.btTienThua.UseVisualStyleBackColor = False
		'
		'btTotal
		'
		Me.btTotal.BackColor = System.Drawing.SystemColors.ControlLight
		Me.btTotal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.btTotal.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btTotal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(106, Byte), Integer), CType(CType(77, Byte), Integer))
		Me.btTotal.Image = Global.WindowsApp1.My.Resources.Resources.total_40x40
		Me.btTotal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me.btTotal.Location = New System.Drawing.Point(666, 473)
		Me.btTotal.Name = "btTotal"
		Me.btTotal.Size = New System.Drawing.Size(189, 44)
		Me.btTotal.TabIndex = 17
		Me.btTotal.Text = "Tổng Cộng"
		Me.btTotal.UseVisualStyleBackColor = False
		'
		'rtbTen
		'
		Me.rtbTen.BackColor = System.Drawing.SystemColors.ControlLight
		Me.rtbTen.Enabled = False
		Me.rtbTen.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.rtbTen.Location = New System.Drawing.Point(666, 58)
		Me.rtbTen.Name = "rtbTen"
		Me.rtbTen.Size = New System.Drawing.Size(189, 398)
		Me.rtbTen.TabIndex = 9
		Me.rtbTen.Text = ""
		'
		'rtbGia
		'
		Me.rtbGia.BackColor = System.Drawing.SystemColors.ControlLight
		Me.rtbGia.Enabled = False
		Me.rtbGia.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.rtbGia.Location = New System.Drawing.Point(858, 59)
		Me.rtbGia.Name = "rtbGia"
		Me.rtbGia.Size = New System.Drawing.Size(108, 398)
		Me.rtbGia.TabIndex = 10
		Me.rtbGia.Text = ""
		'
		'PrintDocument1
		'
		'
		'txtTienThua
		'
		Me.txtTienThua.BackColor = System.Drawing.SystemColors.ControlLight
		Me.txtTienThua.Enabled = False
		Me.txtTienThua.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtTienThua.Location = New System.Drawing.Point(858, 572)
		Me.txtTienThua.Name = "txtTienThua"
		Me.txtTienThua.Size = New System.Drawing.Size(108, 43)
		Me.txtTienThua.TabIndex = 29
		Me.txtTienThua.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		'
		'txtKhachDua
		'
		Me.txtKhachDua.BackColor = System.Drawing.SystemColors.ControlLight
		Me.txtKhachDua.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtKhachDua.Location = New System.Drawing.Point(858, 523)
		Me.txtKhachDua.Name = "txtKhachDua"
		Me.txtKhachDua.Size = New System.Drawing.Size(108, 43)
		Me.txtKhachDua.TabIndex = 29
		Me.txtKhachDua.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		'
		'txtTotal
		'
		Me.txtTotal.BackColor = System.Drawing.SystemColors.ControlLight
		Me.txtTotal.Enabled = False
		Me.txtTotal.Font = New System.Drawing.Font("Calibri", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtTotal.Location = New System.Drawing.Point(858, 474)
		Me.txtTotal.Name = "txtTotal"
		Me.txtTotal.Size = New System.Drawing.Size(108, 43)
		Me.txtTotal.TabIndex = 29
		Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		'
		'Admin_Form
		'
		Me.AcceptButton = Me.btTienThua
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.ControlLight
		Me.ClientSize = New System.Drawing.Size(1155, 620)
		Me.Controls.Add(Me.Panel3)
		Me.Controls.Add(Me.Panel1)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.Name = "Admin_Form"
		Me.Text = "The 1'st Taste Cafe"
		Me.Panel1.ResumeLayout(False)
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.TabControl1.ResumeLayout(False)
		Me.tabCafe.ResumeLayout(False)
		Me.tabCafe.PerformLayout()
		CType(Me.picCafeFin, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picAmericano, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeFlatWhite, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCapuchino, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCacaoNong, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeKemChesse, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeLatte, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeDen, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeLac, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picBacXiu, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeCocktail, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeNong, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeHoaTan, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeRangXay, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picCafeDa, System.ComponentModel.ISupportInitialize).EndInit()
		Me.tabDoAnKhac.ResumeLayout(False)
		Me.tabDoAnKhac.PerformLayout()
		CType(Me.picTraChanh, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picSinhTo, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picTraTuiLoc, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.picTraXanh, System.ComponentModel.ISupportInitialize).EndInit()
		Me.tabDoAnKem.ResumeLayout(False)
		Me.tabDoAnKem.PerformLayout()
		CType(Me.picBanhSungBo, System.ComponentModel.ISupportInitialize).EndInit()
		Me.Panel3.ResumeLayout(False)
		Me.Panel3.PerformLayout()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents tabCafe As TabPage
    Friend WithEvents picCafeFin As PictureBox
    Friend WithEvents lblCafeFin As LinkLabel
    Friend WithEvents lblCafeAmericano As LinkLabel
    Friend WithEvents picAmericano As PictureBox
    Friend WithEvents lblCafeFlatWhite As LinkLabel
    Friend WithEvents picCafeFlatWhite As PictureBox
    Friend WithEvents lblCapuchino As LinkLabel
    Friend WithEvents picCapuchino As PictureBox
    Friend WithEvents lblCacaoNong As LinkLabel
    Friend WithEvents picCacaoNong As PictureBox
    Friend WithEvents lblCafeKemChesse As LinkLabel
    Friend WithEvents picCafeKemChesse As PictureBox
    Friend WithEvents lblCafeLatte As LinkLabel
    Friend WithEvents picCafeLatte As PictureBox
    Friend WithEvents lblCafeDen As LinkLabel
    Friend WithEvents lblCafeLac As LinkLabel
    Friend WithEvents lblBacXiu As LinkLabel
    Friend WithEvents picCafeDen As PictureBox
    Friend WithEvents picCafeLac As PictureBox
    Friend WithEvents picBacXiu As PictureBox
    Friend WithEvents lblCafeCocktail As LinkLabel
    Friend WithEvents lblCafeHoaTan As LinkLabel
    Friend WithEvents lblCafeRangXay As LinkLabel
    Friend WithEvents lblCafeDa As LinkLabel
    Friend WithEvents picCafeCocktail As PictureBox
    Friend WithEvents picCafeNong As PictureBox
    Friend WithEvents picCafeHoaTan As PictureBox
    Friend WithEvents picCafeRangXay As PictureBox
    Friend WithEvents picCafeDa As PictureBox
    Friend WithEvents tabDoAnKhac As TabPage
    Friend WithEvents lblTraChanh As LinkLabel
    Friend WithEvents lblSinhTo As LinkLabel
    Friend WithEvents lblTraTuiLoc As LinkLabel
    Friend WithEvents lblTraXanh As LinkLabel
    Friend WithEvents picTraChanh As PictureBox
    Friend WithEvents picSinhTo As PictureBox
    Friend WithEvents picTraTuiLoc As PictureBox
    Friend WithEvents picTraXanh As PictureBox
    Friend WithEvents tabDoAnKem As TabPage
    Friend WithEvents lblBanhSungBo As LinkLabel
    Friend WithEvents picBanhSungBo As PictureBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents rtbGia As RichTextBox
    Friend WithEvents rtbTen As RichTextBox
	Friend WithEvents btTienThua As Button
	Friend WithEvents btTotal As Button
	Friend WithEvents btInHoaDon As Button
	Friend WithEvents btReset As Button
	Friend WithEvents PrintDocument1 As Printing.PrintDocument
	Friend WithEvents lblCafeNong As LinkLabel
	Friend WithEvents Panel6 As Panel
	Friend WithEvents Button2 As Button
	Friend WithEvents txtTienThua As TextBox
	Friend WithEvents txtTotal As TextBox
	Friend WithEvents txtKhachDua As TextBox
End Class
