﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormLogin2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.txtUser = New System.Windows.Forms.TextBox()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.txtPass = New System.Windows.Forms.TextBox()
		Me.Panel2 = New System.Windows.Forms.Panel()
		Me.btLogin = New System.Windows.Forms.Button()
		Me.btRegister = New System.Windows.Forms.Button()
		Me.PictureBox4 = New System.Windows.Forms.PictureBox()
		Me.PictureBox3 = New System.Windows.Forms.PictureBox()
		Me.PictureBox2 = New System.Windows.Forms.PictureBox()
		Me.PictureBox1 = New System.Windows.Forms.PictureBox()
		CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'txtUser
		'
		Me.txtUser.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.txtUser.Font = New System.Drawing.Font("Consolas", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtUser.ForeColor = System.Drawing.Color.DimGray
		Me.txtUser.Location = New System.Drawing.Point(58, 383)
		Me.txtUser.Name = "txtUser"
		Me.txtUser.Size = New System.Drawing.Size(263, 25)
		Me.txtUser.TabIndex = 4
		'
		'Panel1
		'
		Me.Panel1.BackColor = System.Drawing.Color.DimGray
		Me.Panel1.Location = New System.Drawing.Point(16, 416)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(305, 1)
		Me.Panel1.TabIndex = 5
		'
		'txtPass
		'
		Me.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.txtPass.Font = New System.Drawing.Font("Consolas", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtPass.ForeColor = System.Drawing.Color.DimGray
		Me.txtPass.Location = New System.Drawing.Point(58, 454)
		Me.txtPass.Name = "txtPass"
		Me.txtPass.Size = New System.Drawing.Size(263, 25)
		Me.txtPass.TabIndex = 7
		Me.txtPass.UseSystemPasswordChar = True
		'
		'Panel2
		'
		Me.Panel2.BackColor = System.Drawing.Color.DimGray
		Me.Panel2.Location = New System.Drawing.Point(16, 488)
		Me.Panel2.Name = "Panel2"
		Me.Panel2.Size = New System.Drawing.Size(305, 1)
		Me.Panel2.TabIndex = 6
		'
		'btLogin
		'
		Me.btLogin.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(106, Byte), Integer), CType(CType(77, Byte), Integer))
		Me.btLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.btLogin.Font = New System.Drawing.Font("Consolas", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btLogin.ForeColor = System.Drawing.Color.White
		Me.btLogin.Location = New System.Drawing.Point(16, 533)
		Me.btLogin.Name = "btLogin"
		Me.btLogin.Size = New System.Drawing.Size(299, 48)
		Me.btLogin.TabIndex = 8
		Me.btLogin.Text = "Đăng Nhập"
		Me.btLogin.UseVisualStyleBackColor = False
		'
		'btRegister
		'
		Me.btRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.btRegister.Font = New System.Drawing.Font("Consolas", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btRegister.ForeColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(106, Byte), Integer), CType(CType(77, Byte), Integer))
		Me.btRegister.Location = New System.Drawing.Point(16, 600)
		Me.btRegister.Name = "btRegister"
		Me.btRegister.Size = New System.Drawing.Size(299, 48)
		Me.btRegister.TabIndex = 9
		Me.btRegister.Text = "Đăng Ký"
		Me.btRegister.UseVisualStyleBackColor = True
		'
		'PictureBox4
		'
		Me.PictureBox4.Image = Global.WindowsApp1.My.Resources.Resources.lock_24_512
		Me.PictureBox4.Location = New System.Drawing.Point(16, 452)
		Me.PictureBox4.Name = "PictureBox4"
		Me.PictureBox4.Size = New System.Drawing.Size(30, 30)
		Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PictureBox4.TabIndex = 6
		Me.PictureBox4.TabStop = False
		'
		'PictureBox3
		'
		Me.PictureBox3.Image = Global.WindowsApp1.My.Resources.Resources.user1
		Me.PictureBox3.Location = New System.Drawing.Point(16, 380)
		Me.PictureBox3.Name = "PictureBox3"
		Me.PictureBox3.Size = New System.Drawing.Size(30, 30)
		Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PictureBox3.TabIndex = 2
		Me.PictureBox3.TabStop = False
		'
		'PictureBox2
		'
		Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
		Me.PictureBox2.Image = Global.WindowsApp1.My.Resources.Resources.x_3
		Me.PictureBox2.Location = New System.Drawing.Point(313, 1)
		Me.PictureBox2.Name = "PictureBox2"
		Me.PictureBox2.Size = New System.Drawing.Size(24, 24)
		Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PictureBox2.TabIndex = 1
		Me.PictureBox2.TabStop = False
		'
		'PictureBox1
		'
		Me.PictureBox1.Image = Global.WindowsApp1.My.Resources.Resources.wall_cafe
		Me.PictureBox1.Location = New System.Drawing.Point(-5, -1)
		Me.PictureBox1.Name = "PictureBox1"
		Me.PictureBox1.Size = New System.Drawing.Size(348, 340)
		Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PictureBox1.TabIndex = 0
		Me.PictureBox1.TabStop = False
		'
		'FormLogin2
		'
		Me.AcceptButton = Me.btLogin
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.Color.White
		Me.ClientSize = New System.Drawing.Size(340, 670)
		Me.Controls.Add(Me.btRegister)
		Me.Controls.Add(Me.btLogin)
		Me.Controls.Add(Me.Panel2)
		Me.Controls.Add(Me.txtPass)
		Me.Controls.Add(Me.PictureBox4)
		Me.Controls.Add(Me.Panel1)
		Me.Controls.Add(Me.txtUser)
		Me.Controls.Add(Me.PictureBox3)
		Me.Controls.Add(Me.PictureBox2)
		Me.Controls.Add(Me.PictureBox1)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Name = "FormLogin2"
		Me.Text = "Form_Login_2"
		CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents txtUser As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents txtPass As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents btLogin As Button
    Friend WithEvents btRegister As Button
End Class
