﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formOrder))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.picCafeFin = New System.Windows.Forms.PictureBox()
        Me.lblCafeFin = New System.Windows.Forms.LinkLabel()
        Me.lblCafeAmericano = New System.Windows.Forms.LinkLabel()
        Me.picAmericano = New System.Windows.Forms.PictureBox()
        Me.lblCafeFlatWhite = New System.Windows.Forms.LinkLabel()
        Me.picCafeFlatWhite = New System.Windows.Forms.PictureBox()
        Me.lblCapuchino = New System.Windows.Forms.LinkLabel()
        Me.picCapuchino = New System.Windows.Forms.PictureBox()
        Me.lblCacaoNong = New System.Windows.Forms.LinkLabel()
        Me.picCacaoNong = New System.Windows.Forms.PictureBox()
        Me.lblCafeKemChesse = New System.Windows.Forms.LinkLabel()
        Me.picCafeKemChesse = New System.Windows.Forms.PictureBox()
        Me.lblCafeLatte = New System.Windows.Forms.LinkLabel()
        Me.picCafeLatte = New System.Windows.Forms.PictureBox()
        Me.lblCafeDen = New System.Windows.Forms.LinkLabel()
        Me.lblCafeLac = New System.Windows.Forms.LinkLabel()
        Me.lblBacXiu = New System.Windows.Forms.LinkLabel()
        Me.picCafeDen = New System.Windows.Forms.PictureBox()
        Me.picCafeLac = New System.Windows.Forms.PictureBox()
        Me.picBacXiu = New System.Windows.Forms.PictureBox()
        Me.lblCafeCocktail = New System.Windows.Forms.LinkLabel()
        Me.lblCafeHoaTan = New System.Windows.Forms.LinkLabel()
        Me.lblCafeRangXay = New System.Windows.Forms.LinkLabel()
        Me.lblCafeDa = New System.Windows.Forms.LinkLabel()
        Me.lblCafeNong = New System.Windows.Forms.LinkLabel()
        Me.picCafeCocktail = New System.Windows.Forms.PictureBox()
        Me.picCafeNong = New System.Windows.Forms.PictureBox()
        Me.picCafeHoaTan = New System.Windows.Forms.PictureBox()
        Me.picCafeRangXay = New System.Windows.Forms.PictureBox()
        Me.picCafeDa = New System.Windows.Forms.PictureBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.LinkLabel15 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel14 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel13 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel12 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.LinkLabel16 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox20 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.rtbTen = New System.Windows.Forms.RichTextBox()
        Me.btReset = New System.Windows.Forms.Button()
        Me.rtbGia = New System.Windows.Forms.RichTextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.btTotal = New System.Windows.Forms.Button()
        Me.txtKhachDua = New System.Windows.Forms.TextBox()
        Me.txtTienThua = New System.Windows.Forms.TextBox()
        Me.btTienThua = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btExit = New System.Windows.Forms.Button()
        Me.btInHoaDon = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.picCafeFin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAmericano, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeFlatWhite, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCapuchino, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCacaoNong, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeKemChesse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeLatte, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeDen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeLac, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBacXiu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeCocktail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeNong, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeHoaTan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeRangXay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCafeDa, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(3, 33)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(659, 526)
        Me.TabControl1.TabIndex = 5
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.picCafeFin)
        Me.TabPage1.Controls.Add(Me.lblCafeFin)
        Me.TabPage1.Controls.Add(Me.lblCafeAmericano)
        Me.TabPage1.Controls.Add(Me.picAmericano)
        Me.TabPage1.Controls.Add(Me.lblCafeFlatWhite)
        Me.TabPage1.Controls.Add(Me.picCafeFlatWhite)
        Me.TabPage1.Controls.Add(Me.lblCapuchino)
        Me.TabPage1.Controls.Add(Me.picCapuchino)
        Me.TabPage1.Controls.Add(Me.lblCacaoNong)
        Me.TabPage1.Controls.Add(Me.picCacaoNong)
        Me.TabPage1.Controls.Add(Me.lblCafeKemChesse)
        Me.TabPage1.Controls.Add(Me.picCafeKemChesse)
        Me.TabPage1.Controls.Add(Me.lblCafeLatte)
        Me.TabPage1.Controls.Add(Me.picCafeLatte)
        Me.TabPage1.Controls.Add(Me.lblCafeDen)
        Me.TabPage1.Controls.Add(Me.lblCafeLac)
        Me.TabPage1.Controls.Add(Me.lblBacXiu)
        Me.TabPage1.Controls.Add(Me.picCafeDen)
        Me.TabPage1.Controls.Add(Me.picCafeLac)
        Me.TabPage1.Controls.Add(Me.picBacXiu)
        Me.TabPage1.Controls.Add(Me.lblCafeCocktail)
        Me.TabPage1.Controls.Add(Me.lblCafeHoaTan)
        Me.TabPage1.Controls.Add(Me.lblCafeRangXay)
        Me.TabPage1.Controls.Add(Me.lblCafeDa)
        Me.TabPage1.Controls.Add(Me.lblCafeNong)
        Me.TabPage1.Controls.Add(Me.picCafeCocktail)
        Me.TabPage1.Controls.Add(Me.picCafeNong)
        Me.TabPage1.Controls.Add(Me.picCafeHoaTan)
        Me.TabPage1.Controls.Add(Me.picCafeRangXay)
        Me.TabPage1.Controls.Add(Me.picCafeDa)
        Me.TabPage1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 27)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(651, 495)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Cafe"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'picCafeFin
        '
        Me.picCafeFin.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeFin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeFin.Image = Global.WindowsApp1.My.Resources.Resources.cafe_fin
        Me.picCafeFin.Location = New System.Drawing.Point(407, 193)
        Me.picCafeFin.Name = "picCafeFin"
        Me.picCafeFin.Size = New System.Drawing.Size(90, 100)
        Me.picCafeFin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeFin.TabIndex = 29
        Me.picCafeFin.TabStop = False
        '
        'lblCafeFin
        '
        Me.lblCafeFin.AutoSize = True
        Me.lblCafeFin.Location = New System.Drawing.Point(415, 296)
        Me.lblCafeFin.Name = "lblCafeFin"
        Me.lblCafeFin.Size = New System.Drawing.Size(63, 18)
        Me.lblCafeFin.TabIndex = 28
        Me.lblCafeFin.TabStop = True
        Me.lblCafeFin.Text = "Cafe Fin"
        '
        'lblCafeAmericano
        '
        Me.lblCafeAmericano.AutoSize = True
        Me.lblCafeAmericano.Location = New System.Drawing.Point(404, 443)
        Me.lblCafeAmericano.Name = "lblCafeAmericano"
        Me.lblCafeAmericano.Size = New System.Drawing.Size(114, 18)
        Me.lblCafeAmericano.TabIndex = 27
        Me.lblCafeAmericano.TabStop = True
        Me.lblCafeAmericano.Text = "Cafe Americano"
        '
        'picAmericano
        '
        Me.picAmericano.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picAmericano.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picAmericano.Image = Global.WindowsApp1.My.Resources.Resources._129688
        Me.picAmericano.Location = New System.Drawing.Point(407, 336)
        Me.picAmericano.Name = "picAmericano"
        Me.picAmericano.Size = New System.Drawing.Size(90, 100)
        Me.picAmericano.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAmericano.TabIndex = 26
        Me.picAmericano.TabStop = False
        '
        'lblCafeFlatWhite
        '
        Me.lblCafeFlatWhite.AutoSize = True
        Me.lblCafeFlatWhite.Location = New System.Drawing.Point(263, 443)
        Me.lblCafeFlatWhite.Name = "lblCafeFlatWhite"
        Me.lblCafeFlatWhite.Size = New System.Drawing.Size(109, 18)
        Me.lblCafeFlatWhite.TabIndex = 25
        Me.lblCafeFlatWhite.TabStop = True
        Me.lblCafeFlatWhite.Text = "Cafe Flat White"
        '
        'picCafeFlatWhite
        '
        Me.picCafeFlatWhite.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeFlatWhite.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeFlatWhite.Image = Global.WindowsApp1.My.Resources.Resources.cafe_flat_white_2
        Me.picCafeFlatWhite.Location = New System.Drawing.Point(268, 336)
        Me.picCafeFlatWhite.Name = "picCafeFlatWhite"
        Me.picCafeFlatWhite.Size = New System.Drawing.Size(90, 100)
        Me.picCafeFlatWhite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeFlatWhite.TabIndex = 24
        Me.picCafeFlatWhite.TabStop = False
        '
        'lblCapuchino
        '
        Me.lblCapuchino.AutoSize = True
        Me.lblCapuchino.Location = New System.Drawing.Point(137, 443)
        Me.lblCapuchino.Name = "lblCapuchino"
        Me.lblCapuchino.Size = New System.Drawing.Size(79, 18)
        Me.lblCapuchino.TabIndex = 23
        Me.lblCapuchino.TabStop = True
        Me.lblCapuchino.Text = "Capuchino"
        '
        'picCapuchino
        '
        Me.picCapuchino.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCapuchino.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCapuchino.Image = Global.WindowsApp1.My.Resources.Resources.capuchino1
        Me.picCapuchino.Location = New System.Drawing.Point(139, 336)
        Me.picCapuchino.Name = "picCapuchino"
        Me.picCapuchino.Size = New System.Drawing.Size(90, 100)
        Me.picCapuchino.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCapuchino.TabIndex = 22
        Me.picCapuchino.TabStop = False
        '
        'lblCacaoNong
        '
        Me.lblCacaoNong.AutoSize = True
        Me.lblCacaoNong.Location = New System.Drawing.Point(14, 443)
        Me.lblCacaoNong.Name = "lblCacaoNong"
        Me.lblCacaoNong.Size = New System.Drawing.Size(92, 18)
        Me.lblCacaoNong.TabIndex = 21
        Me.lblCacaoNong.TabStop = True
        Me.lblCacaoNong.Text = "Cacao Nóng"
        '
        'picCacaoNong
        '
        Me.picCacaoNong.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCacaoNong.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCacaoNong.Image = Global.WindowsApp1.My.Resources.Resources.Cacao_Nong
        Me.picCacaoNong.Location = New System.Drawing.Point(17, 336)
        Me.picCacaoNong.Name = "picCacaoNong"
        Me.picCacaoNong.Size = New System.Drawing.Size(90, 100)
        Me.picCacaoNong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCacaoNong.TabIndex = 20
        Me.picCacaoNong.TabStop = False
        '
        'lblCafeKemChesse
        '
        Me.lblCafeKemChesse.AutoSize = True
        Me.lblCafeKemChesse.Location = New System.Drawing.Point(508, 296)
        Me.lblCafeKemChesse.Name = "lblCafeKemChesse"
        Me.lblCafeKemChesse.Size = New System.Drawing.Size(129, 18)
        Me.lblCafeKemChesse.TabIndex = 19
        Me.lblCafeKemChesse.TabStop = True
        Me.lblCafeKemChesse.Text = "Cafe Kem Cheese"
        '
        'picCafeKemChesse
        '
        Me.picCafeKemChesse.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeKemChesse.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeKemChesse.Image = Global.WindowsApp1.My.Resources.Resources.cafe_kem_cheese
        Me.picCafeKemChesse.Location = New System.Drawing.Point(537, 188)
        Me.picCafeKemChesse.Name = "picCafeKemChesse"
        Me.picCafeKemChesse.Size = New System.Drawing.Size(90, 100)
        Me.picCafeKemChesse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeKemChesse.TabIndex = 18
        Me.picCafeKemChesse.TabStop = False
        '
        'lblCafeLatte
        '
        Me.lblCafeLatte.AutoSize = True
        Me.lblCafeLatte.Location = New System.Drawing.Point(524, 443)
        Me.lblCafeLatte.Name = "lblCafeLatte"
        Me.lblCafeLatte.Size = New System.Drawing.Size(75, 18)
        Me.lblCafeLatte.TabIndex = 17
        Me.lblCafeLatte.TabStop = True
        Me.lblCafeLatte.Text = "Cafe Latte"
        '
        'picCafeLatte
        '
        Me.picCafeLatte.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeLatte.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeLatte.Image = Global.WindowsApp1.My.Resources.Resources.cafe_latte
        Me.picCafeLatte.Location = New System.Drawing.Point(527, 336)
        Me.picCafeLatte.Name = "picCafeLatte"
        Me.picCafeLatte.Size = New System.Drawing.Size(90, 100)
        Me.picCafeLatte.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeLatte.TabIndex = 16
        Me.picCafeLatte.TabStop = False
        '
        'lblCafeDen
        '
        Me.lblCafeDen.AutoSize = True
        Me.lblCafeDen.Location = New System.Drawing.Point(265, 296)
        Me.lblCafeDen.Name = "lblCafeDen"
        Me.lblCafeDen.Size = New System.Drawing.Size(70, 18)
        Me.lblCafeDen.TabIndex = 15
        Me.lblCafeDen.TabStop = True
        Me.lblCafeDen.Text = "Cafe Đen"
        '
        'lblCafeLac
        '
        Me.lblCafeLac.AutoSize = True
        Me.lblCafeLac.Location = New System.Drawing.Point(136, 296)
        Me.lblCafeLac.Name = "lblCafeLac"
        Me.lblCafeLac.Size = New System.Drawing.Size(67, 18)
        Me.lblCafeLac.TabIndex = 14
        Me.lblCafeLac.TabStop = True
        Me.lblCafeLac.Text = "Cafe Lắc"
        '
        'lblBacXiu
        '
        Me.lblBacXiu.AutoSize = True
        Me.lblBacXiu.Location = New System.Drawing.Point(14, 296)
        Me.lblBacXiu.Name = "lblBacXiu"
        Me.lblBacXiu.Size = New System.Drawing.Size(59, 18)
        Me.lblBacXiu.TabIndex = 13
        Me.lblBacXiu.TabStop = True
        Me.lblBacXiu.Text = "Bạc Xỉu"
        '
        'picCafeDen
        '
        Me.picCafeDen.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeDen.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeDen.Image = Global.WindowsApp1.My.Resources.Resources.cafe_den
        Me.picCafeDen.Location = New System.Drawing.Point(268, 188)
        Me.picCafeDen.Name = "picCafeDen"
        Me.picCafeDen.Size = New System.Drawing.Size(90, 100)
        Me.picCafeDen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeDen.TabIndex = 12
        Me.picCafeDen.TabStop = False
        '
        'picCafeLac
        '
        Me.picCafeLac.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeLac.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeLac.Image = Global.WindowsApp1.My.Resources.Resources.cafe_lac
        Me.picCafeLac.Location = New System.Drawing.Point(139, 188)
        Me.picCafeLac.Name = "picCafeLac"
        Me.picCafeLac.Size = New System.Drawing.Size(90, 100)
        Me.picCafeLac.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeLac.TabIndex = 11
        Me.picCafeLac.TabStop = False
        '
        'picBacXiu
        '
        Me.picBacXiu.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picBacXiu.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picBacXiu.Image = Global.WindowsApp1.My.Resources.Resources.Bac_Xiu
        Me.picBacXiu.Location = New System.Drawing.Point(17, 188)
        Me.picBacXiu.Name = "picBacXiu"
        Me.picBacXiu.Size = New System.Drawing.Size(90, 100)
        Me.picBacXiu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBacXiu.TabIndex = 10
        Me.picBacXiu.TabStop = False
        '
        'lblCafeCocktail
        '
        Me.lblCafeCocktail.AutoSize = True
        Me.lblCafeCocktail.Location = New System.Drawing.Point(534, 140)
        Me.lblCafeCocktail.Name = "lblCafeCocktail"
        Me.lblCafeCocktail.Size = New System.Drawing.Size(97, 18)
        Me.lblCafeCocktail.TabIndex = 9
        Me.lblCafeCocktail.TabStop = True
        Me.lblCafeCocktail.Text = "Cafe Cocktail"
        '
        'lblCafeHoaTan
        '
        Me.lblCafeHoaTan.AutoSize = True
        Me.lblCafeHoaTan.Location = New System.Drawing.Point(404, 140)
        Me.lblCafeHoaTan.Name = "lblCafeHoaTan"
        Me.lblCafeHoaTan.Size = New System.Drawing.Size(100, 18)
        Me.lblCafeHoaTan.TabIndex = 8
        Me.lblCafeHoaTan.TabStop = True
        Me.lblCafeHoaTan.Text = "Cafe Hoà Tan"
        '
        'lblCafeRangXay
        '
        Me.lblCafeRangXay.AutoSize = True
        Me.lblCafeRangXay.Location = New System.Drawing.Point(265, 140)
        Me.lblCafeRangXay.Name = "lblCafeRangXay"
        Me.lblCafeRangXay.Size = New System.Drawing.Size(107, 18)
        Me.lblCafeRangXay.TabIndex = 7
        Me.lblCafeRangXay.TabStop = True
        Me.lblCafeRangXay.Text = "Cafe Rang Xay"
        '
        'lblCafeDa
        '
        Me.lblCafeDa.AutoSize = True
        Me.lblCafeDa.Location = New System.Drawing.Point(136, 140)
        Me.lblCafeDa.Name = "lblCafeDa"
        Me.lblCafeDa.Size = New System.Drawing.Size(62, 18)
        Me.lblCafeDa.TabIndex = 6
        Me.lblCafeDa.TabStop = True
        Me.lblCafeDa.Text = "Cafe Đá"
        '
        'lblCafeNong
        '
        Me.lblCafeNong.AutoSize = True
        Me.lblCafeNong.Location = New System.Drawing.Point(14, 140)
        Me.lblCafeNong.Name = "lblCafeNong"
        Me.lblCafeNong.Size = New System.Drawing.Size(79, 18)
        Me.lblCafeNong.TabIndex = 5
        Me.lblCafeNong.TabStop = True
        Me.lblCafeNong.Text = "Cafe Nóng"
        '
        'picCafeCocktail
        '
        Me.picCafeCocktail.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeCocktail.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeCocktail.Image = Global.WindowsApp1.My.Resources.Resources.cafe_cocktail
        Me.picCafeCocktail.Location = New System.Drawing.Point(537, 33)
        Me.picCafeCocktail.Name = "picCafeCocktail"
        Me.picCafeCocktail.Size = New System.Drawing.Size(90, 100)
        Me.picCafeCocktail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeCocktail.TabIndex = 4
        Me.picCafeCocktail.TabStop = False
        '
        'picCafeNong
        '
        Me.picCafeNong.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeNong.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeNong.Image = Global.WindowsApp1.My.Resources.Resources._129687
        Me.picCafeNong.Location = New System.Drawing.Point(17, 33)
        Me.picCafeNong.Name = "picCafeNong"
        Me.picCafeNong.Size = New System.Drawing.Size(90, 100)
        Me.picCafeNong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeNong.TabIndex = 0
        Me.picCafeNong.TabStop = False
        '
        'picCafeHoaTan
        '
        Me.picCafeHoaTan.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeHoaTan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeHoaTan.Image = Global.WindowsApp1.My.Resources.Resources.cafe_hoà_tan
        Me.picCafeHoaTan.Location = New System.Drawing.Point(407, 33)
        Me.picCafeHoaTan.Name = "picCafeHoaTan"
        Me.picCafeHoaTan.Size = New System.Drawing.Size(90, 100)
        Me.picCafeHoaTan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeHoaTan.TabIndex = 3
        Me.picCafeHoaTan.TabStop = False
        '
        'picCafeRangXay
        '
        Me.picCafeRangXay.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeRangXay.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeRangXay.Image = Global.WindowsApp1.My.Resources.Resources._129683
        Me.picCafeRangXay.Location = New System.Drawing.Point(268, 33)
        Me.picCafeRangXay.Name = "picCafeRangXay"
        Me.picCafeRangXay.Size = New System.Drawing.Size(90, 100)
        Me.picCafeRangXay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeRangXay.TabIndex = 1
        Me.picCafeRangXay.TabStop = False
        '
        'picCafeDa
        '
        Me.picCafeDa.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picCafeDa.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picCafeDa.Image = Global.WindowsApp1.My.Resources.Resources.iced_coffee
        Me.picCafeDa.Location = New System.Drawing.Point(139, 33)
        Me.picCafeDa.Name = "picCafeDa"
        Me.picCafeDa.Size = New System.Drawing.Size(90, 100)
        Me.picCafeDa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCafeDa.TabIndex = 2
        Me.picCafeDa.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.LinkLabel15)
        Me.TabPage2.Controls.Add(Me.LinkLabel14)
        Me.TabPage2.Controls.Add(Me.LinkLabel13)
        Me.TabPage2.Controls.Add(Me.LinkLabel12)
        Me.TabPage2.Controls.Add(Me.PictureBox19)
        Me.TabPage2.Controls.Add(Me.PictureBox18)
        Me.TabPage2.Controls.Add(Me.PictureBox16)
        Me.TabPage2.Controls.Add(Me.PictureBox15)
        Me.TabPage2.Location = New System.Drawing.Point(4, 27)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(651, 495)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Đồ Uống Khác"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'LinkLabel15
        '
        Me.LinkLabel15.AutoSize = True
        Me.LinkLabel15.Location = New System.Drawing.Point(441, 137)
        Me.LinkLabel15.Name = "LinkLabel15"
        Me.LinkLabel15.Size = New System.Drawing.Size(77, 18)
        Me.LinkLabel15.TabIndex = 12
        Me.LinkLabel15.TabStop = True
        Me.LinkLabel15.Text = "Trà Chanh"
        '
        'LinkLabel14
        '
        Me.LinkLabel14.AutoSize = True
        Me.LinkLabel14.Location = New System.Drawing.Point(299, 137)
        Me.LinkLabel14.Name = "LinkLabel14"
        Me.LinkLabel14.Size = New System.Drawing.Size(59, 18)
        Me.LinkLabel14.TabIndex = 10
        Me.LinkLabel14.TabStop = True
        Me.LinkLabel14.Text = "Sinh Tố"
        '
        'LinkLabel13
        '
        Me.LinkLabel13.AutoSize = True
        Me.LinkLabel13.Location = New System.Drawing.Point(153, 137)
        Me.LinkLabel13.Name = "LinkLabel13"
        Me.LinkLabel13.Size = New System.Drawing.Size(83, 18)
        Me.LinkLabel13.TabIndex = 8
        Me.LinkLabel13.TabStop = True
        Me.LinkLabel13.Text = "Trà Túi Lọc"
        '
        'LinkLabel12
        '
        Me.LinkLabel12.AutoSize = True
        Me.LinkLabel12.Location = New System.Drawing.Point(14, 137)
        Me.LinkLabel12.Name = "LinkLabel12"
        Me.LinkLabel12.Size = New System.Drawing.Size(68, 18)
        Me.LinkLabel12.TabIndex = 6
        Me.LinkLabel12.TabStop = True
        Me.LinkLabel12.Text = "Trà Xanh"
        '
        'PictureBox19
        '
        Me.PictureBox19.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox19.Image = Global.WindowsApp1.My.Resources.Resources.Tra_chanh
        Me.PictureBox19.Location = New System.Drawing.Point(444, 15)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox19.TabIndex = 11
        Me.PictureBox19.TabStop = False
        '
        'PictureBox18
        '
        Me.PictureBox18.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox18.Image = Global.WindowsApp1.My.Resources.Resources.sinh_to_da
        Me.PictureBox18.Location = New System.Drawing.Point(302, 15)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox18.TabIndex = 9
        Me.PictureBox18.TabStop = False
        '
        'PictureBox16
        '
        Me.PictureBox16.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox16.Image = Global.WindowsApp1.My.Resources.Resources.Tra_tui_loc
        Me.PictureBox16.Location = New System.Drawing.Point(156, 15)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox16.TabIndex = 7
        Me.PictureBox16.TabStop = False
        '
        'PictureBox15
        '
        Me.PictureBox15.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox15.Image = Global.WindowsApp1.My.Resources.Resources.Tra_xanh
        Me.PictureBox15.Location = New System.Drawing.Point(17, 15)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox15.TabIndex = 1
        Me.PictureBox15.TabStop = False
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.LinkLabel16)
        Me.TabPage3.Controls.Add(Me.PictureBox20)
        Me.TabPage3.Location = New System.Drawing.Point(4, 27)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(651, 495)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Đồ Ăn Kèm"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'LinkLabel16
        '
        Me.LinkLabel16.AutoSize = True
        Me.LinkLabel16.Location = New System.Drawing.Point(12, 129)
        Me.LinkLabel16.Name = "LinkLabel16"
        Me.LinkLabel16.Size = New System.Drawing.Size(103, 18)
        Me.LinkLabel16.TabIndex = 9
        Me.LinkLabel16.TabStop = True
        Me.LinkLabel16.Text = "Bánh Sừng Bò"
        '
        'PictureBox20
        '
        Me.PictureBox20.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox20.Image = Global.WindowsApp1.My.Resources.Resources.Banh_sung_bo
        Me.PictureBox20.Location = New System.Drawing.Point(15, 15)
        Me.PictureBox20.Name = "PictureBox20"
        Me.PictureBox20.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox20.TabIndex = 8
        Me.PictureBox20.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(701, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(148, 25)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "THANH TOÁN"
        '
        'rtbTen
        '
        Me.rtbTen.Enabled = False
        Me.rtbTen.Location = New System.Drawing.Point(669, 60)
        Me.rtbTen.Name = "rtbTen"
        Me.rtbTen.Size = New System.Drawing.Size(189, 398)
        Me.rtbTen.TabIndex = 7
        Me.rtbTen.Text = ""
        '
        'btReset
        '
        Me.btReset.Location = New System.Drawing.Point(897, 31)
        Me.btReset.Name = "btReset"
        Me.btReset.Size = New System.Drawing.Size(75, 23)
        Me.btReset.TabIndex = 9
        Me.btReset.Text = "&Reset"
        Me.btReset.UseVisualStyleBackColor = True
        '
        'rtbGia
        '
        Me.rtbGia.Enabled = False
        Me.rtbGia.Location = New System.Drawing.Point(864, 60)
        Me.rtbGia.Name = "rtbGia"
        Me.rtbGia.Size = New System.Drawing.Size(108, 398)
        Me.rtbGia.TabIndex = 8
        Me.rtbGia.Text = ""
        '
        'txtTotal
        '
        Me.txtTotal.Enabled = False
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.Location = New System.Drawing.Point(864, 478)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(108, 26)
        Me.txtTotal.TabIndex = 10
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btTotal
        '
        Me.btTotal.Location = New System.Drawing.Point(669, 478)
        Me.btTotal.Name = "btTotal"
        Me.btTotal.Size = New System.Drawing.Size(75, 23)
        Me.btTotal.TabIndex = 11
        Me.btTotal.Text = "&Tính Tổng"
        Me.btTotal.UseVisualStyleBackColor = True
        '
        'txtKhachDua
        '
        Me.txtKhachDua.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtKhachDua.Location = New System.Drawing.Point(864, 510)
        Me.txtKhachDua.Name = "txtKhachDua"
        Me.txtKhachDua.Size = New System.Drawing.Size(108, 26)
        Me.txtKhachDua.TabIndex = 12
        Me.txtKhachDua.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTienThua
        '
        Me.txtTienThua.Enabled = False
        Me.txtTienThua.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTienThua.Location = New System.Drawing.Point(864, 546)
        Me.txtTienThua.Name = "txtTienThua"
        Me.txtTienThua.Size = New System.Drawing.Size(108, 26)
        Me.txtTienThua.TabIndex = 13
        Me.txtTienThua.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btTienThua
        '
        Me.btTienThua.Location = New System.Drawing.Point(669, 546)
        Me.btTienThua.Name = "btTienThua"
        Me.btTienThua.Size = New System.Drawing.Size(75, 23)
        Me.btTienThua.TabIndex = 14
        Me.btTienThua.Text = "&Tiền Thừa"
        Me.btTienThua.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(668, 516)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 20)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Khách đưa:"
        '
        'btExit
        '
        Me.btExit.Location = New System.Drawing.Point(897, 2)
        Me.btExit.Name = "btExit"
        Me.btExit.Size = New System.Drawing.Size(75, 23)
        Me.btExit.TabIndex = 16
        Me.btExit.Text = "&Thoát"
        Me.btExit.UseVisualStyleBackColor = True
        '
        'btInHoaDon
        '
        Me.btInHoaDon.Location = New System.Drawing.Point(7, 4)
        Me.btInHoaDon.Name = "btInHoaDon"
        Me.btInHoaDon.Size = New System.Drawing.Size(75, 23)
        Me.btInHoaDon.TabIndex = 17
        Me.btInHoaDon.Text = "&In Hoá Đơn"
        Me.btInHoaDon.UseVisualStyleBackColor = True
        '
        'PrintDocument1
        '
        '
        'formOrder
        '
        Me.AcceptButton = Me.btTienThua
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 582)
        Me.Controls.Add(Me.btInHoaDon)
        Me.Controls.Add(Me.btExit)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btTienThua)
        Me.Controls.Add(Me.txtTienThua)
        Me.Controls.Add(Me.txtKhachDua)
        Me.Controls.Add(Me.btTotal)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.btReset)
        Me.Controls.Add(Me.rtbGia)
        Me.Controls.Add(Me.rtbTen)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "formOrder"
        Me.Text = "Đặt Đồ"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.picCafeFin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAmericano, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeFlatWhite, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCapuchino, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCacaoNong, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeKemChesse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeLatte, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeDen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeLac, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBacXiu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeCocktail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeNong, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeHoaTan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeRangXay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCafeDa, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picCafeNong As PictureBox
    Friend WithEvents picCafeRangXay As PictureBox
    Friend WithEvents picCafeDa As PictureBox
    Friend WithEvents picCafeHoaTan As PictureBox
    Friend WithEvents picCafeCocktail As PictureBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents picBacXiu As PictureBox
    Friend WithEvents lblCafeCocktail As LinkLabel
    Friend WithEvents lblCafeHoaTan As LinkLabel
    Friend WithEvents lblCafeRangXay As LinkLabel
    Friend WithEvents lblCafeDa As LinkLabel
    Friend WithEvents lblCafeNong As LinkLabel
    Friend WithEvents picCafeLac As PictureBox
    Friend WithEvents picCafeDen As PictureBox
    Friend WithEvents picCafeLatte As PictureBox
    Friend WithEvents lblCafeDen As LinkLabel
    Friend WithEvents lblCafeLac As LinkLabel
    Friend WithEvents lblBacXiu As LinkLabel
    Friend WithEvents picCafeKemChesse As PictureBox
    Friend WithEvents lblCafeLatte As LinkLabel
    Friend WithEvents picCacaoNong As PictureBox
    Friend WithEvents lblCafeKemChesse As LinkLabel
    Friend WithEvents picCapuchino As PictureBox
    Friend WithEvents lblCacaoNong As LinkLabel
    Friend WithEvents lblCapuchino As LinkLabel
    Friend WithEvents picCafeFlatWhite As PictureBox
    Friend WithEvents lblCafeFin As LinkLabel
    Friend WithEvents lblCafeAmericano As LinkLabel
    Friend WithEvents picAmericano As PictureBox
    Friend WithEvents lblCafeFlatWhite As LinkLabel
    Friend WithEvents PictureBox15 As PictureBox
    Friend WithEvents PictureBox16 As PictureBox
    Friend WithEvents LinkLabel12 As LinkLabel
    Friend WithEvents picCafeFin As PictureBox
    Friend WithEvents LinkLabel13 As LinkLabel
    Friend WithEvents PictureBox18 As PictureBox
    Friend WithEvents PictureBox19 As PictureBox
    Friend WithEvents LinkLabel14 As LinkLabel
    Friend WithEvents LinkLabel15 As LinkLabel
    Friend WithEvents PictureBox20 As PictureBox
    Friend WithEvents LinkLabel16 As LinkLabel
    Friend WithEvents Label1 As Label
    Friend WithEvents rtbTen As RichTextBox
    Friend WithEvents btReset As Button
    Friend WithEvents rtbGia As RichTextBox
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents btTotal As Button
    Friend WithEvents txtKhachDua As TextBox
    Friend WithEvents txtTienThua As TextBox
    Friend WithEvents btTienThua As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents btExit As Button
    Friend WithEvents btInHoaDon As Button
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
End Class
