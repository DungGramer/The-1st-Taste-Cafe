﻿Namespace txtPass
    Friend Class Text
    End Class
End Namespace
