﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formLogin))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.lblPass = New System.Windows.Forms.Label()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.btLogin = New System.Windows.Forms.Button()
        Me.btRegister = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(180, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(335, 42)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "The 1'st Taste cafe"
        '
        'lblUser
        '
        Me.lblUser.AutoSize = True
        Me.lblUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.Location = New System.Drawing.Point(142, 202)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(101, 24)
        Me.lblUser.TabIndex = 1
        Me.lblUser.Text = "Tài Khoản:"
        '
        'lblPass
        '
        Me.lblPass.AutoSize = True
        Me.lblPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPass.Location = New System.Drawing.Point(142, 266)
        Me.lblPass.Name = "lblPass"
        Me.lblPass.Size = New System.Drawing.Size(94, 24)
        Me.lblPass.TabIndex = 2
        Me.lblPass.Text = "Mật Khẩu:"
        '
        'txtUser
        '
        Me.txtUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUser.Location = New System.Drawing.Point(277, 199)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(263, 29)
        Me.txtUser.TabIndex = 3
        '
        'txtPass
        '
        Me.txtPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPass.Location = New System.Drawing.Point(277, 261)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPass.Size = New System.Drawing.Size(263, 29)
        Me.txtPass.TabIndex = 4
        '
        'btLogin
        '
        Me.btLogin.Location = New System.Drawing.Point(209, 366)
        Me.btLogin.Name = "btLogin"
        Me.btLogin.Size = New System.Drawing.Size(132, 48)
        Me.btLogin.TabIndex = 5
        Me.btLogin.Text = "&Đăng Nhập"
        Me.btLogin.UseVisualStyleBackColor = True
        '
        'btRegister
        '
        Me.btRegister.Location = New System.Drawing.Point(349, 366)
        Me.btRegister.Name = "btRegister"
        Me.btRegister.Size = New System.Drawing.Size(132, 48)
        Me.btRegister.TabIndex = 7
        Me.btRegister.Text = "&Đăng Ký"
        Me.btRegister.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(202, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(278, 37)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Cafe Thượng Giác"
        '
        'formLogin
        '
        Me.AcceptButton = Me.btLogin
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(684, 461)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btRegister)
        Me.Controls.Add(Me.btLogin)
        Me.Controls.Add(Me.txtPass)
        Me.Controls.Add(Me.txtUser)
        Me.Controls.Add(Me.lblPass)
        Me.Controls.Add(Me.lblUser)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "formLogin"
        Me.Text = "The 1'st Taste Cafe"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lblUser As Label
    Friend WithEvents lblPass As Label
    Friend WithEvents txtUser As TextBox
    Friend WithEvents txtPass As TextBox
    Friend WithEvents btLogin As Button
    Friend WithEvents btRegister As Button
    Friend WithEvents Label2 As Label
End Class
