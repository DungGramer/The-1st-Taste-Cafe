﻿Public Class formPrint

    Private Sub PrintDocument1_PrintPage_1(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim reportFont As Font = New Drawing.Font("Time New Roman", 14)
        e.Graphics.DrawString("The 1'st Taste Cafe", reportFont, Brushes.Chocolate, 100, 100)
        e.Graphics.DrawString("= = = = = = = = = =", reportFont, Brushes.Chocolate, 100, 100)
        e.Graphics.DrawString("", reportFont, Brushes.Chocolate, 100, 100)
    End Sub

    Private Sub formPrint_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PrintPreviewControl1.Document = PrintDocument1
        PrintDocument1.Print
    End Sub

    Private Sub PrintPreviewControl1_Click(sender As Object, e As EventArgs) Handles PrintPreviewControl1.Click

    End Sub
End Class