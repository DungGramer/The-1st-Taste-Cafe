﻿Public Class FormLogin2
	Dim a As Integer = 0
	Private Sub Form_Login_2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		txtUser.Focus()
	End Sub
	Private Sub PictureBox2_Click_1(sender As Object, e As EventArgs) Handles PictureBox2.Click
		Me.Close()
	End Sub
	Private Sub btLogin_Click(sender As Object, e As EventArgs) Handles btLogin.Click
		If txtUser.Text = "admin" And txtPass.Text = "admin" Then
			a = 2
			Me.Hide()
			Admin_Form.Show()
		End If
		If txtUser.Text = My.Settings.txtUser Then
			a += 1
		End If
		If txtPass.Text = My.Settings.txtPass Then
			a += 1
		End If
		If a = 2 Then
			Me.Hide()
			Admin_Form.Show()
		Else
			MsgBox("Tài Khoản hoặc Mật Khẩu không đúng! Vui lòng thử lại !", MsgBoxStyle.Exclamation)
		End If
	End Sub
	Private Sub btRegister_Click(sender As Object, e As EventArgs) Handles btRegister.Click
		Me.Hide()
		formRegister3.Show()
	End Sub
End Class