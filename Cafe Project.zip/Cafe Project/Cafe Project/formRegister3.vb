﻿Public Class formRegister3
	Private Sub btRegister_Click(sender As Object, e As EventArgs) Handles btRegister.Click
		Dim p As String = txtPass.Text
		If txtUser.Text = "" Then
			MsgBox("Hãy nhập tên đăng nhập của bạn!")
			txtUser.Focus()
		ElseIf txtPass.Text = "" Then
			MsgBox("Hãy nhập mật khẩu của bạn!")
			txtPass.Focus()
		ElseIf txtRepass.Text = "" Then
			MsgBox("Hãy nhập lại mật khẩu của bạn !")
			txtRepass.Focus()
		ElseIf txtRepass.Text <> p Then
			MsgBox("Mật Khẩu không trùng nhau. Vui lòng nhập lại Mật Khẩu", MsgBoxStyle.Exclamation)
			txtRepass.Focus()
		ElseIf txtRepass.Text = p Then
			My.Settings.txtUser = txtUser.Text
			My.Settings.txtPass = txtPass.Text
			My.Settings.Save()
			MsgBox("Đăng Ký Thành Công !")
			Me.Hide()
			FormLogin2.Show()
		End If
	End Sub
	Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
		Me.Hide()
		FormLogin2.Show()
	End Sub
End Class