﻿Public Class formLogin
    Dim a As Integer = 0

    Private Sub btLogin_Click(sender As Object, e As EventArgs) Handles btLogin.Click

        If txtUser.Text = "admin" And txtPass.Text = "admin" Then
            a = 2
            Me.Hide()
            Admin_Form.Show()
        End If

        If txtUser.Text = My.Settings.txtUser Then
            a += 1
        End If
        If txtPass.Text = My.Settings.txtPass Then
            a += 1
        End If

        If a = 2 Then
            Me.Hide()
            Admin_Form.Show()
        Else
            MsgBox("Tài Khoản hoặc Mật Khẩu không đúng! Vui lòng thử lại !", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub btRegister_Click(sender As Object, e As EventArgs) Handles btRegister.Click
        Me.Hide()
        formRegister.Show()
    End Sub

End Class
