﻿Imports System.Drawing.Drawing2D
Public Class Admin_Form
	Dim price_cafeNong As Decimal = 25
	Dim price_cafeDa As Decimal = 30
	Dim price_cafeRangXay As Decimal = 50
	Dim price_cafeHoaTan As Decimal = 20
	Dim price_cafeCocktail As Decimal = 35
	Dim price_BacXiu As Decimal = 35
	Dim price_cafeLac As Decimal = 35
	Dim price_cafeDen As Decimal = 30
	Dim price_cafeFin As Decimal = 30
	Dim price_cafeKemCheese As Decimal = 35
	Dim price_cacaoNong As Decimal = 30
	Dim price_capuchino As Decimal = 70
	Dim price_cafeFlatWhite As Decimal = 45
	Dim price_cafeAmericano As Decimal = 55
	Dim price_cafeLatte As Decimal = 70
	Dim price_traXanh As Decimal = 20
	Dim price_traTuiLoc As Decimal = 15
	Dim price_sinhTo As Decimal = 35
	Dim price_traChanh As Decimal = 15
	Dim price_banhSungBo As Decimal = 10

	Dim selected_cafeNong As Decimal = 0
	Dim selected_cafeDa As Decimal = 0
	Dim selected_cafeRangXay As Decimal = 0
	Dim selected_cafeHoaTan As Decimal = 0
	Dim selected_cafeCocktail As Decimal = 0
	Dim selected_BacXiu As Decimal = 0
	Dim selected_cafeLac As Decimal = 0
	Dim selected_cafeDen As Decimal = 0
	Dim selected_cafeFin As Decimal = 0
	Dim selected_cafeKemCheese As Decimal = 0
	Dim selected_cacaoNong As Decimal = 0
	Dim selected_capuchino As Decimal = 0
	Dim selected_cafeFlatWhite As Decimal = 0
	Dim selected_cafeAmericano As Decimal = 0
	Dim selected_cafeLatte As Decimal = 0
	Dim selected_traXanh As Decimal = 0
	Dim selected_traTuiLoc As Decimal = 0
	Dim selected_sinhTo As Decimal = 0
	Dim selected_traChanh As Decimal = 0
	Dim selected_banhSungBo As Decimal = 0

	Private Sub picCafeNong_Click(sender As Object, e As EventArgs) Handles picCafeNong.Click
		selected_cafeNong += 1
		rtbTen.Text = rtbTen.Text & lblCafeNong.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeNong & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeNong_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeNong.LinkClicked
		selected_cafeNong += 1
		rtbTen.Text = rtbTen.Text & lblCafeNong.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeNong & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeDa_Click(sender As Object, e As EventArgs) Handles picCafeDa.Click
		selected_cafeDa += 1
		rtbTen.Text = rtbTen.Text & lblCafeDa.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeDa & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeDa_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeDa.LinkClicked
		selected_cafeDa += 1
		rtbTen.Text = rtbTen.Text & lblCafeDa.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeDa & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeRangXay_Click(sender As Object, e As EventArgs) Handles picCafeRangXay.Click
		selected_cafeRangXay += 1
		rtbTen.Text = rtbTen.Text & lblCafeRangXay.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeRangXay & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeRangXay_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeRangXay.LinkClicked
		selected_cafeRangXay += 1
		rtbTen.Text = rtbTen.Text & lblCafeRangXay.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeRangXay & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeHoaTan_Click(sender As Object, e As EventArgs) Handles picCafeHoaTan.Click
		selected_cafeHoaTan += 1
		rtbTen.Text = rtbTen.Text & lblCafeHoaTan.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeHoaTan & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeHoaTan_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeHoaTan.LinkClicked
		selected_cafeHoaTan += 1
		rtbTen.Text = rtbTen.Text & lblCafeHoaTan.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeHoaTan & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeCocktail_Click(sender As Object, e As EventArgs) Handles picCafeCocktail.Click
		selected_cafeCocktail += 1
		rtbTen.Text = rtbTen.Text & lblCafeCocktail.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeCocktail & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeCocktail_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeCocktail.LinkClicked
		selected_cafeCocktail += 1
		rtbTen.Text = rtbTen.Text & lblCafeCocktail.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeCocktail & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picBacXiu_Click(sender As Object, e As EventArgs) Handles picBacXiu.Click
		selected_BacXiu += 1
		rtbTen.Text = rtbTen.Text & lblBacXiu.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_BacXiu & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblBacXiu_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblBacXiu.LinkClicked
		selected_BacXiu += 1
		rtbTen.Text = rtbTen.Text & lblBacXiu.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_BacXiu & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeLac_Click(sender As Object, e As EventArgs) Handles picCafeLac.Click
		selected_cafeLac += 1
		rtbTen.Text = rtbTen.Text & lblCafeLac.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeLac & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeLac_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeLac.LinkClicked
		selected_cafeLac += 1
		rtbTen.Text = rtbTen.Text & lblCafeLac.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeLac & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeDen_Click(sender As Object, e As EventArgs) Handles picCafeDen.Click
		selected_cafeDen += 1
		rtbTen.Text = rtbTen.Text & lblCafeDen.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeDen & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeDen_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeDen.LinkClicked
		selected_cafeDen += 1
		rtbTen.Text = rtbTen.Text & lblCafeDen.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeDen & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeFin_Click(sender As Object, e As EventArgs) Handles picCafeFin.Click
		selected_cafeFin += 1
		rtbTen.Text = rtbTen.Text & lblCafeFin.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeFin & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeFin_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeFin.LinkClicked
		selected_cafeFin += 1
		rtbTen.Text = rtbTen.Text & lblCafeFin.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeFin & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeKemChesse_Click(sender As Object, e As EventArgs) Handles picCafeKemChesse.Click
		selected_cafeKemCheese += 1
		rtbTen.Text = rtbTen.Text & lblCafeKemChesse.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeKemCheese & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeKemChesse_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeKemChesse.LinkClicked
		selected_cafeKemCheese += 1
		rtbTen.Text = rtbTen.Text & lblCafeKemChesse.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeKemCheese & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCacaoNong_Click(sender As Object, e As EventArgs) Handles picCacaoNong.Click
		selected_cacaoNong += 1
		rtbTen.Text = rtbTen.Text & lblCacaoNong.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cacaoNong & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCacaoNong_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCacaoNong.LinkClicked
		selected_cacaoNong += 1
		rtbTen.Text = rtbTen.Text & lblCacaoNong.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cacaoNong & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCapuchino_Click(sender As Object, e As EventArgs) Handles picCapuchino.Click
		selected_capuchino += 1
		rtbTen.Text = rtbTen.Text & lblCapuchino.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_capuchino & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCapuchino_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCapuchino.LinkClicked
		selected_capuchino += 1
		rtbTen.Text = rtbTen.Text & lblCapuchino.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_capuchino & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeFlatWhite_Click(sender As Object, e As EventArgs) Handles picCafeFlatWhite.Click
		selected_cafeFlatWhite += 1
		rtbTen.Text = rtbTen.Text & lblCafeFlatWhite.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeFlatWhite & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeFlatWhite_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeFlatWhite.LinkClicked
		selected_cafeFlatWhite += 1
		rtbTen.Text = rtbTen.Text & lblCafeFlatWhite.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeFlatWhite & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picAmericano_Click(sender As Object, e As EventArgs) Handles picAmericano.Click
		selected_cafeAmericano += 1
		rtbTen.Text = rtbTen.Text & lblCafeAmericano.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeAmericano & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeAmericano_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeAmericano.LinkClicked
		selected_cafeAmericano += 1
		rtbTen.Text = rtbTen.Text & lblCafeAmericano.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeAmericano & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picCafeLatte_Click(sender As Object, e As EventArgs) Handles picCafeLatte.Click
		selected_cafeLatte += 1
		rtbTen.Text = rtbTen.Text & lblCafeLatte.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeLatte & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblCafeLatte_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblCafeLatte.LinkClicked
		selected_cafeLatte += 1
		rtbTen.Text = rtbTen.Text & lblCafeLatte.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_cafeLatte & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picTraXanh_Click(sender As Object, e As EventArgs) Handles picTraXanh.Click
		selected_traXanh += 1
		rtbTen.Text = rtbTen.Text & lblTraXanh.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_traXanh & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblTraXanh_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblTraXanh.LinkClicked
		selected_traXanh += 1
		rtbTen.Text = rtbTen.Text & lblTraXanh.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_traXanh & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picTraTuiLoc_Click(sender As Object, e As EventArgs) Handles picTraTuiLoc.Click
		selected_traTuiLoc += 1
		rtbTen.Text = rtbTen.Text & lblTraTuiLoc.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_traTuiLoc & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblTraTuiLoc_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblTraTuiLoc.LinkClicked
		selected_traTuiLoc += 1
		rtbTen.Text = rtbTen.Text & lblTraTuiLoc.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_traTuiLoc & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picSinhTo_Click(sender As Object, e As EventArgs) Handles picSinhTo.Click
		selected_sinhTo += 1
		rtbTen.Text = rtbTen.Text & lblSinhTo.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_sinhTo & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblSinhTo_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblSinhTo.LinkClicked
		selected_sinhTo += 1
		rtbTen.Text = rtbTen.Text & lblSinhTo.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_sinhTo & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picTraChanh_Click(sender As Object, e As EventArgs) Handles picTraChanh.Click
		selected_traChanh += 1
		rtbTen.Text = rtbTen.Text & lblTraChanh.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_traChanh & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblTraChanh_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblTraChanh.LinkClicked
		selected_traChanh += 1
		rtbTen.Text = rtbTen.Text & lblTraChanh.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_traChanh & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub picBanhSungBo_Click(sender As Object, e As EventArgs) Handles picBanhSungBo.Click
		selected_banhSungBo += 1
		rtbTen.Text = rtbTen.Text & lblBanhSungBo.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_banhSungBo & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub lblBanhSungBo_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblBanhSungBo.LinkClicked
		selected_banhSungBo += 1
		rtbTen.Text = rtbTen.Text & lblBanhSungBo.Text & vbNewLine
		rtbGia.Text = rtbGia.Text & price_banhSungBo & ".000 vnđ" & vbNewLine
	End Sub
	Private Sub btTotal_Click(sender As Object, e As EventArgs) Handles btTotal.Click
		Dim tCafeNong = price_cafeNong * selected_cafeNong
		Dim tCafeDa = price_cafeDa * selected_cafeDa
		Dim tcafeRangXay = price_cafeRangXay * selected_cafeRangXay
		Dim tcafeHoaTan = price_cafeHoaTan * selected_cafeHoaTan
		Dim tcafeCockTail = price_cafeCocktail * selected_cafeCocktail
		Dim tBacXiu = price_BacXiu * selected_BacXiu
		Dim tcafeLac = price_cafeLac * selected_cafeLac
		Dim tcafeDen = price_cafeDen * selected_cafeDen
		Dim tcafeFin = price_cafeFin * selected_cafeFin
		Dim tcafeKemChesse = price_cafeKemCheese * selected_cafeKemCheese
		Dim tcacaoNong = price_cacaoNong * selected_cacaoNong
		Dim tcapuchino = price_capuchino * selected_capuchino
		Dim tcafeFlatWhite = price_cafeFlatWhite * selected_cafeFlatWhite
		Dim tcafeAmericano = price_cafeAmericano * selected_cafeAmericano
		Dim tcafeLatte = price_cafeLatte * selected_cafeLatte
		Dim tTraXanh = price_traXanh * selected_traXanh
		Dim tTraTuiLoc = price_traTuiLoc * selected_traTuiLoc
		Dim tSinhTo = price_sinhTo * selected_sinhTo
		Dim tTraChanh = price_traChanh * selected_traChanh
		Dim tBanhSungBo = price_banhSungBo * selected_banhSungBo

		Dim Total = tCafeNong + tCafeDa + tcafeRangXay + tcafeHoaTan + tcafeCockTail + tBacXiu + tcafeLac + tcafeDen + tcafeFin + tcafeKemChesse + tcacaoNong + tcapuchino + tcafeFlatWhite + tcafeAmericano + tcafeLatte + tTraXanh + tTraTuiLoc + tSinhTo + tTraChanh + tBanhSungBo
		txtTotal.Text = Total
		txtKhachDua.Focus()
	End Sub
	Private Sub btReset_Click(sender As Object, e As EventArgs) Handles btReset.Click
		rtbTen.Text = ""
		rtbGia.Text = ""
		txtTotal.Text = ""
		txtTienThua.Text = ""
		txtKhachDua.Text = ""
		selected_cafeNong = 0
		selected_cafeDa = 0
		selected_cafeRangXay = 0
		selected_cafeHoaTan = 0
		selected_cafeCocktail = 0
		selected_BacXiu = 0
		selected_cafeLac = 0
		selected_cafeDen = 0
		selected_cafeFin = 0
		selected_cafeKemCheese = 0
		selected_cacaoNong = 0
		selected_capuchino = 0
		selected_cafeFlatWhite = 0
		selected_cafeAmericano = 0
		selected_cafeLatte = 0
		selected_traXanh = 0
		selected_traChanh = 0
		selected_traTuiLoc = 0
		selected_sinhTo = 0
		selected_banhSungBo = 0
	End Sub
	Private Sub btTienThua_Click(sender As Object, e As EventArgs) Handles btTienThua.Click
		txtTienThua.Text = txtKhachDua.Text - txtTotal.Text
		If txtTienThua.Text < 0 Then
			MsgBox("Khách đã đưa thiếu " & txtTienThua.Text * -1 & ".000 vnđ. Vui lòng đưa đủ tiền.", MsgBoxStyle.Exclamation)
		ElseIf txtTienThua.Text = 0 Then
			MsgBox("Cảm ơn quý khách. Chúc quý khách ngon miệng ^^!")
		Else
			MsgBox("Xin gửi lại quý khách " & txtTienThua.Text & ".000 vnđ. Chúc quý khách ngon miệng ^^!")
		End If
	End Sub
	Private Sub btInHoaDon_Click(sender As Object, e As EventArgs) Handles btInHoaDon.Click
		If txtTienThua.Text < 0 Then
			MsgBox("Khách đã đưa thiếu " & txtTienThua.Text * -1 & ".000 vnđ. Vui lòng đưa đủ tiền trước khi in hoá đơn.", MsgBoxStyle.Exclamation)
		ElseIf txtTienThua.Text >= 0 Then
			PrintDocument1.Print()
		End If
	End Sub
	Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

		'Dim logo As Image = Image.FromFile("D:\Download\Documents\Visual Studio 2017\Projects\Cafe Project\Cafe Project\Resources\logo black.png")
		Dim pFont As Font = New Drawing.Font("Consolas", 16)
		Dim Header As Font = New Drawing.Font("Consolas", 32)
		Dim Tel As Font = New Drawing.Font("Consolas", 20)
		Dim Bold As Font = New Drawing.Font("Calibri Bold", 25)
		Dim TD As Font = New Drawing.Font("Calibri Bold", 30)
		'e.Graphics.DrawImage(logo, 40, 40, 200, 200)
		e.Graphics.DrawString("The 1'st Taste Cafe" + vbNewLine, Header, Brushes.Black, 340, 50)
		e.Graphics.DrawString("Tel: 0334.565.999", Tel, Brushes.Black, 550, 101)
		e.Graphics.DrawString("HOÁ ĐƠN THANH TOÁN", TD, Brushes.Black, 160, 192)
		e.Graphics.DrawString("Ngày bán:", pFont, Brushes.Black, 35, 300)
		e.Graphics.DrawString(Date.Now.ToString("dd/MM/yyyy hh:mm"), pFont, Brushes.Black, 152, 300)
		e.Graphics.DrawString("-------------------------------------------------------------", pFont, Brushes.Black, 35, 335)
		e.Graphics.DrawString("Mặt Hàng", Bold, Brushes.Black, 35, 370)
		e.Graphics.DrawString(rtbTen.Text + vbNewLine, Tel, Brushes.Black, 35, 420)
		e.Graphics.DrawString("Số Tiền", Bold, Brushes.Black, 685, 370)
		e.Graphics.DrawString(rtbGia.Text + vbNewLine, Tel, Brushes.Black, 650, 420)
		e.Graphics.DrawString("TỔNG TIỀN PHẢI T.TOÁN", Tel, Brushes.Black, 30, 880)
		e.Graphics.DrawString(txtTotal.Text + ".000 vnđ", Tel, Brushes.Black, 638, 880)
		e.Graphics.DrawString("TIỀN KHÁCH ĐƯA", Tel, Brushes.Black, 30, 920)
		e.Graphics.DrawString(txtKhachDua.Text + ".000 vnđ", Tel, Brushes.Black, 638, 920)
		e.Graphics.DrawString("TIỀN TRẢ LẠI", Tel, Brushes.Black, 30, 960)
		e.Graphics.DrawString(txtTienThua.Text + ".000 vnđ", Tel, Brushes.Black, 638, 960)
		e.Graphics.DrawString("CẢM ƠN QUÝ KHÁCH VÀ HẸN GẶP LẠI", Tel, Brushes.Black, 190, 1040)
	End Sub

End Class
